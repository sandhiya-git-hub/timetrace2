import express from 'express';
import { randomBytes } from 'crypto';
import type { DeviceState } from '../../../shared/types/chronotrace.js';
import type { UserRecord, AuthSession, DeviceRecord } from '../types/models.js';
import { getUsers, saveUsers, getAuthSessions, saveAuthSessions } from './userStore.js';
import { isAgentLive } from './dataStore.js';

export function getSessionToken(req: express.Request): string | null {
  if (req.cookies && req.cookies['chronotrace_session']) {
    return req.cookies['chronotrace_session'];
  }
  const authHeader = req.headers['authorization'];
  if (authHeader && authHeader.startsWith('Bearer ')) {
    return authHeader.substring(7).trim();
  }
  if (req.headers['x-session-token']) {
    return String(req.headers['x-session-token']).trim();
  }
  return null;
}

export function getAuthenticatedUser(req: express.Request): UserRecord | null {
  const token = getSessionToken(req);
  if (!token) return null;

  const sessions = getAuthSessions();
  const session = sessions[token];
  if (!session) return null;

  if (new Date(session.expiresAt) <= new Date()) {
    delete sessions[token];
    saveAuthSessions(sessions);
    return null;
  }

  const users = getUsers();
  const user = users.find((u) => u.id === session.userId);
  return user || null;
}

// Access-control guard for every data route. Only a valid, unexpired session
// cookie (or Bearer token) resolves to a user. Anything else gets 401.
export const DATA_ALIAS_PREFIXES = [
  '/sessions', '/summary', '/reentry', '/patterns',
  '/download', '/agent.py', '/chronotrace_agent.py',
  '/public/agent.py', '/public/chronotrace_agent.py',
];

// Routes that authenticate in a different way (agent device token) or are public.
export const SESSION_EXEMPT_PATHS = new Set([
  '/api/auth/session', '/api/auth/config', '/api/auth/login', '/api/auth/register',
  '/api/auth/google', '/api/auth/logout',
  '/api/ingest-event', '/api/sync-sessions', '/api/agent/sync-file',
]);

export const SESSION_COOKIE_NAME = 'chronotrace_session';
export const SESSION_TTL_MS = 30 * 24 * 3600 * 1000; // 30 days

// Set COOKIE_SECURE=true when the site is served over HTTPS. It is off by default so
// local http://localhost development keeps working.
export function sessionCookieOptions() {
  return {
    httpOnly: true,
    sameSite: 'lax' as const,
    path: '/',
    secure: process.env.COOKIE_SECURE === 'true',
    maxAge: SESSION_TTL_MS,
  };
}

export function requireSessionUser(req: express.Request, res: express.Response, next: express.NextFunction) {
  const p = req.path;
  if (SESSION_EXEMPT_PATHS.has(p)) return next();
  const isData = p.startsWith('/api/') || DATA_ALIAS_PREFIXES.some((x) => p.startsWith(x));
  if (!isData) return next();
  const user = getAuthenticatedUser(req);
  if (!user) {
    return res.status(401).json({ error: 'Sign in required.' });
  }
  res.locals.user = user;
  return next();
}

export function createSessionForUser(user: UserRecord): { token: string; expiresAt: string } {
  const token = `ct_sess_${randomBytes(32).toString('hex')}`;
  const expiresAt = new Date(Date.now() + 30 * 24 * 3600 * 1000).toISOString(); // 30 days
  const sessions = getAuthSessions();
  sessions[token] = {
    token,
    userId: user.id,
    createdAt: new Date().toISOString(),
    expiresAt,
  };
  saveAuthSessions(sessions);
  return { token, expiresAt };
}

export function toUserProfile(u: UserRecord) {
  return {
    id: u.id,
    username: u.username,
    email: u.email,
    name: u.name,
    givenName: u.givenName,
    picture: u.picture,
    deviceToken: u.deviceToken,
    emailVerified: true,
    lastLogin: u.lastLogin,
    isRegistered: u.isRegistered !== false,
    hasConfiguredDevice: u.hasConfiguredDevice !== false,
  };
}

export function toDeviceStatus(rec: DeviceRecord, eventCount: number = 0): DeviceState {
  const connected = isAgentLive(rec);
  let status: DeviceState['status'];
  let statusText: string;

  if (connected) {
    if (eventCount > 0 && rec.lastEventTime) {
      status = 'CONNECTED';
      statusText = 'Connected · Receiving telemetry';
    } else {
      status = 'CONNECTED_AWAITING_ACTIVITY';
      statusText = 'Connected · Awaiting activity';
    }
  } else if (rec.paused) {
    status = 'NOT_CONNECTED';
    statusText = 'Not Connected · Collection paused';
  } else if (rec.lastSuccessfulConnectionAt) {
    status = 'DISCONNECTED';
    statusText = `Disconnected · Last active ${rec.lastEventTime || 'previously'}`;
  } else {
    status = 'NOT_CONNECTED';
    statusText = 'Not Connected · Device not registered';
  }

  return {
    connected,
    status,
    paused: rec.paused,
    deviceName: rec.deviceName,
    os: rec.os,
    agentVersion: rec.agentVersion,
    samplingInterval: rec.samplingInterval,
    lastEventTime: rec.lastEventTime,
    lastLocalDate: rec.lastLocalDate || new Date().toISOString().split('T')[0],
    eventCount,
    statusText,
    lastPing: rec.lastHeartbeatAt,
    lastHeartbeatAt: rec.lastHeartbeatAt,
    connectedSince: connected ? rec.connectedSince : null,
    lastSuccessfulConnectionAt: rec.lastSuccessfulConnectionAt,
  };
}
