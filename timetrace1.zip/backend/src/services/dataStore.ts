import fs from 'fs';
import path from 'path';
import { DATA_DIR } from '../config/env.js';
import type { ChunkSummary, DailySynthesis, TelemetryEvent } from '../../../shared/types/chronotrace.js';
import type { DeviceRecord } from '../types/models.js';

export function getUserDir(userId: string): string {
  const dir = path.join(DATA_DIR, 'users', userId);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  return dir;
}


export const defaultDeviceRecord: DeviceRecord = {
  paused: false,
  deviceName: 'Windows Workstation',
  os: 'Windows 11 64-bit',
  agentVersion: '1.3.0',
  samplingInterval: '500ms',
  lastHeartbeatAt: null,
  connectedSince: null,
  lastSuccessfulConnectionAt: null,
  lastEventTime: null,
  lastLocalDate: null,
};

export const HEARTBEAT_TIMEOUT_MS = 45_000;

export const isAgentLive = (rec: DeviceRecord, nowMs: number = Date.now()): boolean =>
  !rec.paused &&
  !!rec.lastHeartbeatAt &&
  nowMs - Date.parse(rec.lastHeartbeatAt) <= HEARTBEAT_TIMEOUT_MS;

export function getUserDeviceRecord(userId: string): DeviceRecord {
  const devFile = path.join(getUserDir(userId), 'device.json');
  try {
    if (fs.existsSync(devFile)) {
      const stored = JSON.parse(fs.readFileSync(devFile, 'utf-8'));
      return { ...defaultDeviceRecord, ...stored };
    }
  } catch {}
  return { ...defaultDeviceRecord };
}

export function saveUserDeviceRecord(userId: string, rec: DeviceRecord) {
  const devFile = path.join(getUserDir(userId), 'device.json');
  try {
    fs.writeFileSync(devFile, JSON.stringify(rec, null, 2), 'utf-8');
  } catch (e) {
    console.error(`Could not save device state for user ${userId}:`, e);
  }
}

export function getUserTelemetry(userId: string): TelemetryEvent[] {
  const file = path.join(getUserDir(userId), 'telemetry.json');
  try {
    if (fs.existsSync(file)) {
      return JSON.parse(fs.readFileSync(file, 'utf-8'));
    }
  } catch {}
  return [];
}

export function saveUserTelemetry(userId: string, events: TelemetryEvent[]) {
  const file = path.join(getUserDir(userId), 'telemetry.json');
  try {
    fs.writeFileSync(file, JSON.stringify(events, null, 2), 'utf-8');
  } catch (e) {
    console.error(`Could not save telemetry for user ${userId}:`, e);
  }
}

export function getUserSessions(userId: string): ChunkSummary[] {
  const file = path.join(getUserDir(userId), 'sessions.json');
  try {
    if (fs.existsSync(file)) {
      return JSON.parse(fs.readFileSync(file, 'utf-8'));
    }
  } catch {}
  return [];
}

export function saveUserSessions(userId: string, sessions: ChunkSummary[]) {
  const file = path.join(getUserDir(userId), 'sessions.json');
  try {
    fs.writeFileSync(file, JSON.stringify(sessions, null, 2), 'utf-8');
  } catch (e) {
    console.error(`Could not save sessions for user ${userId}:`, e);
  }
}

export function getUserSummary(userId: string): DailySynthesis {
  const file = path.join(getUserDir(userId), 'summary.json');
  try {
    if (fs.existsSync(file)) {
      return JSON.parse(fs.readFileSync(file, 'utf-8'));
    }
  } catch {}
  return {
    date: new Date().toISOString().split('T')[0],
    total_deep_work_s: 0,
    total_distraction_s: 0,
    total_telemetry_s: 0,
    fragmentation_score: 0,
    peak_focus_window: 'No activity yet',
    context_switches: 0,
    distraction_triggers: [],
    daily_narrative: 'Waiting for activity collection from your Windows agent.',
    unfinished_work: [],
    work_state: 'settled',
  };
}

export function saveUserSummary(userId: string, summary: DailySynthesis) {
  const file = path.join(getUserDir(userId), 'summary.json');
  try {
    fs.writeFileSync(file, JSON.stringify(summary, null, 2), 'utf-8');
  } catch (e) {
    console.error(`Could not save summary for user ${userId}:`, e);
  }
}

