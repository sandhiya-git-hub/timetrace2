import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import {
  validateName,
  validateUsername,
  validateEmail,
  validatePassword,
  validateConfirmPassword,
  validateRegistration,
} from '../../shared/validation/auth.js';

describe('name rules', () => {
  it('accepts real names, including accents, apostrophes, hyphens and periods', () => {
    for (const name of ['Alex Morgan', "Siobhán O'Brien", 'Anne-Marie Lee', 'José Núñez', 'Dr. Jane Q. Doe Jr.']) {
      assert.equal(validateName(name), null, `expected "${name}" to be valid`);
    }
  });

  it('requires a value and at least two characters', () => {
    assert.equal(validateName('   '), 'Full name is required.');
    assert.match(validateName('A') ?? '', /at least 2/);
  });

  it('rejects digits and other symbols', () => {
    assert.match(validateName('Alex3') ?? '', /only contain letters/);
    assert.match(validateName('<script>') ?? '', /only contain letters/);
    assert.match(validateName('-Alex') ?? '', /only contain letters/);
  });

  it('caps the length at 60 characters', () => {
    assert.equal(validateName('A'.repeat(60)), null);
    assert.match(validateName('A'.repeat(61)) ?? '', /60 characters or fewer/);
  });
});

describe('username rules', () => {
  it('accepts 3–20 letters, numbers and underscores', () => {
    assert.equal(validateUsername('abc'), null);
    assert.equal(validateUsername('User_name_01'), null);
    assert.equal(validateUsername('a'.repeat(20)), null);
  });

  it('rejects out-of-range lengths and other characters', () => {
    assert.match(validateUsername('ab') ?? '', /3–20/);
    assert.match(validateUsername('a'.repeat(21)) ?? '', /3–20/);
    assert.match(validateUsername('bad name') ?? '', /letters, numbers and underscores/);
    assert.match(validateUsername('bad-name') ?? '', /letters, numbers and underscores/);
    assert.match(validateUsername('alex!') ?? '', /letters, numbers and underscores/);
    assert.equal(validateUsername('  '), 'Username is required.');
  });
});

describe('email rules', () => {
  it('accepts valid addresses regardless of case or surrounding spaces', () => {
    assert.equal(validateEmail('  Test@Example.com  '), null);
    assert.equal(validateEmail('first.last+tag@sub.domain.co.uk'), null);
  });

  it('rejects malformed addresses and requires a value', () => {
    for (const email of ['foo', 'foo@bar', 'a b@x.com', 'foo@@bar.com', '@example.com', 'foo@-bad.com']) {
      assert.notEqual(validateEmail(email), null, `expected "${email}" to be rejected`);
    }
    assert.equal(validateEmail(''), 'Email address is required.');
  });
});

describe('password rules', () => {
  it('accepts a password with upper, lower, number and special character', () => {
    assert.equal(validatePassword('Secret123!'), null);
    assert.equal(validatePassword('Tr0ub4dor&3'), null);
  });

  it('enforces the minimum length of 8 characters', () => {
    assert.match(validatePassword('Abc123!') ?? '', /at least 8 characters/);
  });

  it('requires each character class', () => {
    assert.match(validatePassword('alllowercase1!') ?? '', /uppercase/);
    assert.match(validatePassword('ALLUPPERCASE1!') ?? '', /lowercase/);
    assert.match(validatePassword('NoNumbers!!') ?? '', /number/);
    assert.match(validatePassword('NoSpecial123') ?? '', /special character/);
  });

  it('rejects passwords longer than 72 bytes, because bcrypt would ignore the tail', () => {
    assert.match(validatePassword('Aa1!' + 'x'.repeat(70)) ?? '', /72 bytes or fewer/);
  });

  it('confirm password must match exactly', () => {
    assert.equal(validateConfirmPassword('Secret123!', 'Secret123!'), null);
    assert.equal(validateConfirmPassword('Secret123!', ''), 'Please confirm your password.');
    assert.equal(validateConfirmPassword('Secret123!', 'Secret123'), 'Passwords do not match.');
  });
});

describe('validateRegistration', () => {
  it('reports every invalid field at once and normalizes valid values', () => {
    const result = validateRegistration({
      name: '  Alex   Morgan ',
      username: ' Alex_01 ',
      email: ' Alex@Example.COM ',
      password: 'Secret123!',
      confirmPassword: 'Secret123!',
    });
    assert.equal(result.valid, true);
    assert.deepEqual(result.values, { name: 'Alex Morgan', username: 'alex_01', email: 'alex@example.com' });

    const bad = validateRegistration({ name: '', username: 'x', email: 'nope', password: 'weak', confirmPassword: 'other' });
    assert.equal(bad.valid, false);
    assert.deepEqual(Object.keys(bad.errors).sort(), ['confirmPassword', 'email', 'name', 'password', 'username']);
  });
});
