#!/usr/bin/env python3
"""
ChronoTrace Exact-Duration & Topic-Aware Laptop Telemetry Agent
- Zero external pip packages required (100% Python Standard Library)
- Tracks exact seconds spent in every foreground window before switching
- Intelligently classifies YouTube & Social Media topics into Productive (Learning) vs Non-Productive (Entertainment)
- Automatically synchronizes live foreground window activity to the web dashboard for passive activity reconstruction
- Saves live session history to ~/chronotrace_live.json & http://127.0.0.1:9876/live
"""
import os
import re
import time
import json
import platform
import subprocess
import threading
import urllib.error
import urllib.request
import sys
import ssl
import hashlib
import base64
import struct
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

try:
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(line_buffering=True)
except Exception:
    pass

PORT = 9876

# Default Server Host and User Token (dynamically injected on download or provided via argv)
DEFAULT_SERVER = "https://ais-dev-4teaxvnjoinhftmkpzwwzs-735460948524.asia-southeast1.run.app"
DEFAULT_USER_TOKEN = ""

# Parse CLI arguments for server URL and user token
SERVER_BASE = DEFAULT_SERVER
USER_TOKEN = DEFAULT_USER_TOKEN

args = sys.argv[1:]
idx = 0
while idx < len(args):
    arg = args[idx].strip()
    if arg in ("--token", "-t") and idx + 1 < len(args):
        USER_TOKEN = args[idx + 1].strip().strip("\"'")
        idx += 2
        continue
    elif arg.startswith("--token="):
        USER_TOKEN = arg.split("=", 1)[1].strip().strip("\"'")
        idx += 1
        continue
    elif not arg.startswith("-"):
        raw_val = arg.rstrip("/").strip("\"'")
        if not raw_val.startswith("http://") and not raw_val.startswith("https://"):
            SERVER_BASE = "https://" + raw_val
        else:
            SERVER_BASE = raw_val
    idx += 1

USER_TOKEN = USER_TOKEN.strip("\"' ")
SERVER_BASE = SERVER_BASE.strip("\"' ")

REMOTE_ENDPOINT = f"{SERVER_BASE}/api/ingest-event"
REMOTE_SYNC = f"{SERVER_BASE}/api/sync-sessions"
LIVE_JSON_PATH = os.path.join(os.path.expanduser("~"), "chronotrace_live.json")

_link_state = {"connected": None}

def _report_link(ok, detail=""):
    """Print only on state changes so the terminal shows why the device is or is not connected."""
    if ok and _link_state["connected"] is not True:
        _link_state["connected"] = True
        print(f"[CONNECTED] Linked to ChronoTrace website ({SERVER_BASE})")
    elif not ok and _link_state["connected"] is not False:
        _link_state["connected"] = False
        print(f"[NOT CONNECTED] {detail}")

def _get_ssl_context():
    try:
        return ssl.create_default_context()
    except Exception:
        try:
            return ssl._create_unverified_context()
        except Exception:
            return None

def push_to_remote(payload):
    try:
        now_dt = datetime.now().astimezone()
        tz_offset_min = int(now_dt.utcoffset().total_seconds() // 60) if now_dt.utcoffset() else 0
        tz_name = now_dt.tzname() or (time.tzname[time.daylight] if (time.daylight and len(time.tzname) > 1) else time.tzname[0])

        if "localTime" not in payload:
            payload["localTime"] = now_dt.strftime("%I:%M:%S %p")
        if "localDate" not in payload:
            payload["localDate"] = now_dt.strftime("%Y-%m-%d")
        if "localTimestamp" not in payload:
            payload["localTimestamp"] = now_dt.isoformat()
        if "utcTimestamp" not in payload:
            payload["utcTimestamp"] = datetime.now(timezone.utc).isoformat()
        if "timezoneOffsetMinutes" not in payload:
            payload["timezoneOffsetMinutes"] = tz_offset_min
        if "timezoneName" not in payload:
            payload["timezoneName"] = tz_name
        if USER_TOKEN and "userToken" not in payload:
            payload["userToken"] = USER_TOKEN

        headers = {
            "Content-Type": "application/json",
            "User-Agent": "ChronoTraceAgent/1.3.0"
        }
        if USER_TOKEN:
            headers["Authorization"] = f"Bearer {USER_TOKEN}"
            headers["X-User-Token"] = USER_TOKEN

        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            REMOTE_ENDPOINT,
            data=data,
            headers=headers,
            method="POST"
        )
        ctx = _get_ssl_context()
        try:
            resp = urllib.request.urlopen(req, context=ctx, timeout=8) if ctx else urllib.request.urlopen(req, timeout=8)
        except urllib.error.URLError as u_err:
            err_msg = str(u_err)
            if "CERTIFICATE_VERIFY_FAILED" in err_msg or "certificate" in err_msg.lower() or "ssl" in err_msg.lower():
                try:
                    unv = ssl._create_unverified_context()
                    resp = urllib.request.urlopen(req, context=unv, timeout=8)
                except Exception:
                    raise u_err
            else:
                raise u_err

        with resp:
            content_type = resp.headers.get("Content-Type", "")
            if "text/html" in content_type:
                # Intercepted by Cloud Run preview proxy; file sync is active
                _report_link(False, "Activity is actively being recorded! Saved to ~/chronotrace_live.json. On the ChronoTrace website, click 'Connect Live File' or 'Import JSON' to stream live.")
                return False
            if resp.status in (200, 201):
                _report_link(True)
                return True
            _report_link(False, f"Unexpected HTTP status {resp.status}")
            return False
    except urllib.error.HTTPError as e:
        if e.code == 409:
            _report_link(False, "Activity collection is paused on the website; resume it on the dashboard.")
        elif e.code in (401, 403):
            _report_link(False, f"HTTP {e.code} Authentication Failed: Device token is invalid or unassigned.")
        else:
            _report_link(False, f"HTTP {e.code} {e.reason}")
        return False
    except urllib.error.URLError as e:
        _report_link(False, f"Local WebSocket active (Remote: {e.reason})")
        return False
    except Exception as e:
        _report_link(False, f"Local WebSocket active ({e})")
        return False

FRIENDLY_MAP = {
    "code": "VS Code",
    "chrome": "Google Chrome",
    "msedge": "Microsoft Edge",
    "brave": "Brave Browser",
    "firefox": "Firefox",
    "whatsapp": "WhatsApp",
    "calculatorapp": "Calculator",
    "calc": "Calculator",
    "windowsterminal": "PowerShell",
    "powershell": "PowerShell",
    "cmd": "Command Prompt",
    "explorer": "File Explorer",
    "spotify": "Spotify",
    "slack": "Slack",
    "discord": "Discord",
    "notion": "Notion"
}

PRODUCTIVE_KW = [
    "tutorial", "course", "lecture", "lesson", "algorithm", "graph", "dijkstra", "bfs", "dfs",
    "dynamic programming", "tree", "array", "data structure", "leetcode", "coding", "programming",
    "software", "developer", "engineering", "python", "javascript", "typescript", "react", "node",
    "java", "c++", "rust", "golang", "sql", "database", "docker", "kubernetes", "aws", "cloud",
    "devops", "linux", "git", "github", "system design", "architecture", "api", "frontend", "backend",
    "machine learning", "deep learning", "ai", "artificial intelligence", "llm", "neural", "gpt",
    "gemini", "rag", "agent", "pytorch", "tensorflow", "data science", "analytics", "statistics",
    "math", "calculus", "linear algebra", "physics", "chemistry", "biology", "science", "robotics",
    "cybersecurity", "networking", "operating system", "compiler", "blockchain", "ui", "ux", "figma",
    "design", "startup", "business", "finance", "economics", "investing", "marketing", "seo",
    "productivity", "study", "learn", "learning", "how to", "explained", "guide", "walkthrough",
    "crash course", "masterclass", "bootcamp", "workshop", "seminar", "paper", "research", "arxiv",
    "interview", "resume", "career", "roadmap", "prep", "exam", "gate", "jee", "neet", "upsc",
    "documentary", "history", "philosophy", "psychology", "neuroscience", "medicine", "law",
    "book summary", "audiobook", "podcast", "ted", "mit", "stanford", "harvard", "cs50",
    "freecodecamp", "fireship", "3blue1brown", "neetcode", "striver", "coursera", "udemy",
    "how ", "why ", "what is", "building", "creating", "implementing", "solving", "debugging",
    "understanding", "intro to", "basics of", "advanced", "deep dive", "analysis", "breakdown"
]

NON_PRODUCTIVE_KW = [
    "prank", "vlog", "funny", "comedy", "meme", "roast", "reaction", "unboxing", "gossip", "drama",
    "trailer", "teaser", "movie", "episode", "netflix", "anime", "gaming", "gameplay", "valorant",
    "minecraft", "fortnite", "gta", "roblox", "pubg", "bgmi", "cod", "fifa", "elden ring", "twitch",
    "esports", "speedrun", "music video", "official video", "lyrics", "karaoke", "song", "remix",
    "playlist", "bollywood", "kpop", "dance", "tiktok", "reels", "shorts feed", "asmr", "mukbang",
    "food challenge", "makeup", "grwm", "fashion", "sports highlights", "cricket", "ipl", "football"
]

sessions = []
current_state = {
    "appName": "Waiting...",
    "windowTitle": "Initializing...",
    "elapsedSeconds": 0,
    "timestamp": time.time()
}

def parse_window_exact(raw_app, raw_title):
    clean_title = (raw_title or raw_app or "Active Window").strip()
    app_name = (raw_app or "Application").strip()
    segments = [s.strip() for s in clean_title.replace("—", " - ").split(" - ") if s.strip()]
    last_seg = segments[-1].lower() if segments else ""
    t_low = clean_title.lower()
    a_low = app_name.lower()

    if "visual studio code" in last_seg or a_low == "code":
        app_name = "VS Code"
    elif "google chrome" in last_seg or a_low == "chrome":
        app_name = "Google Chrome"
    elif "microsoft edge" in last_seg or a_low == "msedge":
        app_name = "Microsoft Edge"
    elif "whatsapp" in t_low or "whatsapp" in a_low:
        app_name = "WhatsApp"
    elif "calculator" in t_low or "calc" in a_low:
        app_name = "Calculator"
    elif "powershell" in t_low or a_low in ["powershell", "windowsterminal"]:
        app_name = "PowerShell"

    content_segs = list(segments)
    if len(content_segs) > 1 and any(b in last_seg for b in ["google chrome", "visual studio code", "microsoft edge", "brave", "firefox"]):
        content_segs.pop()

    primary = content_segs[0] if content_segs else clean_title
    secondary = " — ".join(content_segs[1:]) if len(content_segs) > 1 else app_name

    is_yt_or_social = any(s in t_low for s in ["youtube", "reddit", "linkedin", "twitter", "x.com", "medium", "instagram"])

    if app_name == "VS Code":
        cat = "Deep Work"
        task = f"Editing {content_segs[0]} ({content_segs[1]})" if len(content_segs) >= 2 else f"VS Code: {primary}"
        topics = [content_segs[0]]
    elif is_yt_or_social:
        topic_clean = re.sub(r"^\(\d+\)\s*", "", primary).strip()
        platform_name = "YouTube" if "youtube" in t_low else ("Reddit" if "reddit" in t_low else "Social Media")
        has_prod = any(k in t_low for k in PRODUCTIVE_KW)
        has_non_prod = any(k in t_low for k in NON_PRODUCTIVE_KW)
        if has_prod and not has_non_prod:
            cat = "Learning"
            task = f"{platform_name} (Productive Learning): {topic_clean}"
            topics = [topic_clean]
        else:
            cat = "Entertainment"
            task = f"{platform_name} (Leisure / Non-Productive): {topic_clean}"
            topics = []
    elif app_name == "WhatsApp" or any(k in t_low for k in ["slack", "discord", "telegram", "teams"]):
        cat = "Communication"
        task = f"{app_name}: {primary}"
        topics = []
    elif app_name == "Calculator":
        cat = "Utility"
        task = f"Calculator: {clean_title}"
        topics = []
    elif any(k in t_low for k in PRODUCTIVE_KW):
        cat = "Learning"
        task = f"{primary} ({secondary})"
        topics = [primary]
    elif any(k in t_low for k in NON_PRODUCTIVE_KW):
        cat = "Entertainment"
        task = f"{primary} ({secondary})"
        topics = []
    else:
        is_work = any(k in t_low for k in ["ai studio", "chronotrace", "localhost", "127.0.0.1", "docs.google", "sheets.google", "figma", "notion"])
        cat = "Deep Work" if is_work else "Utility"
        task = f"{primary} ({secondary})" if len(content_segs) > 1 else f"{app_name}: {primary}"
        topics = [primary] if is_work else []

    return app_name, secondary, task, cat, topics

def get_windows_active_window():
    try:
        import ctypes
        from ctypes import wintypes
        user32 = ctypes.windll.user32
        kernel32 = ctypes.windll.kernel32
        psapi = ctypes.windll.psapi

        hwnd = user32.GetForegroundWindow()
        if not hwnd:
            return None, None
        length = user32.GetWindowTextLengthW(hwnd)
        buf = ctypes.create_unicode_buffer(length + 1)
        user32.GetWindowTextW(hwnd, buf, length + 1)
        title = buf.value.strip()
        if not title:
            return None, None

        pid = wintypes.DWORD()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        
        # Try PROCESS_QUERY_LIMITED_INFORMATION (0x1000) first to read elevated/UWP process titles
        h_process = kernel32.OpenProcess(0x1000, False, pid.value)
        if not h_process:
            h_process = kernel32.OpenProcess(0x0400 | 0x0010, False, pid.value)

        app_name = ""
        if h_process:
            exe_buf = ctypes.create_unicode_buffer(512)
            size = wintypes.DWORD(512)
            if hasattr(kernel32, 'QueryFullProcessImageNameW') and kernel32.QueryFullProcessImageNameW(h_process, 0, exe_buf, ctypes.byref(size)):
                full_path = exe_buf.value
                app_name = os.path.basename(full_path).replace(".exe", "").replace(".EXE", "")
            elif psapi.GetModuleBaseNameW(h_process, None, exe_buf, 512) > 0:
                app_name = exe_buf.value.replace(".exe", "").replace(".EXE", "")
            kernel32.CloseHandle(h_process)

        if not app_name:
            parts = [p.strip() for p in title.split(" - ") if p.strip()]
            app_name = parts[-1] if len(parts) >= 2 else "Windows App"

        norm = FRIENDLY_MAP.get(app_name.lower(), app_name)
        return norm, title
    except Exception:
        return None, None

def get_macos_active_window():
    try:
        app_cmd = 'tell application "System Events" to get name of first application process whose frontmost is true'
        title_cmd = 'tell application "System Events" to tell (first application process whose frontmost is true) to get name of front window'
        app_name = subprocess.check_output(["osascript", "-e", app_cmd], stderr=subprocess.DEVNULL).decode("utf-8", errors="ignore").strip()
        try:
            win_title = subprocess.check_output(["osascript", "-e", title_cmd], stderr=subprocess.DEVNULL).decode("utf-8", errors="ignore").strip()
        except Exception:
            win_title = app_name
        return app_name or "macOS App", win_title or app_name
    except Exception:
        return None, None

def get_linux_active_window():
    try:
        win_id = subprocess.check_output(["xdotool", "getactivewindow"], stderr=subprocess.DEVNULL).decode().strip()
        win_title = subprocess.check_output(["xdotool", "getwindowname", win_id], stderr=subprocess.DEVNULL).decode().strip()
        app_name = win_title.split(" - ")[-1] if " - " in win_title else "Linux App"
        return app_name, win_title
    except Exception:
        return None, None

def save_live_json():
    try:
        now_iso = datetime.now(timezone.utc).isoformat()
        payload_data = {
            "status": "ok",
            "heartbeat": True,
            "lastHeartbeatAt": now_iso,
            "connected": True,
            "deviceName": platform.node() or "Windows Workstation",
            "os": f"{platform.system()} {platform.release()}",
            "userToken": USER_TOKEN,
            "current": current_state,
            "sessions": sessions
        }
        with open(LIVE_JSON_PATH, "w", encoding="utf-8") as f:
            json.dump(payload_data, f, indent=2)
        # Also write to local working directory for immediate access
        with open("chronotrace_live.json", "w", encoding="utf-8") as f:
            json.dump(payload_data, f, indent=2)
    except Exception:
        pass

def format_sec(s):
    s = int(round(s))
    if s < 60:
        return f"{s}s"
    return f"{s // 60}m {s % 60}s"

def poll_os_loop():
    sys_name = platform.system()
    last_tick = time.time()
    tick_count = 0

    while True:
        time.sleep(1)
        now = time.time()
        delta = max(1, round(now - last_tick))
        last_tick = now
        tick_count += 1

        try:
            if sys_name == "Windows":
                raw_app, raw_title = get_windows_active_window()
            elif sys_name == "Darwin":
                raw_app, raw_title = get_macos_active_window()
            else:
                raw_app, raw_title = get_linux_active_window()

            if not raw_app or not raw_title:
                # No readable window (e.g. lock screen). Still heartbeat so the
                # website knows the agent is running.
                push_to_remote({"heartbeat": True, "sourceType": "os-hook"})
                continue

            app_name, site_mod, task, cat, topics = parse_window_exact(raw_app, raw_title)
            now_str = datetime.now().strftime("%H:%M:%S")
            sig = f"{app_name}:::{raw_title}"

            if sessions and f"{sessions[-1]['appName']}:::{sessions[-1]['windowTitle']}" == sig:
                sessions[-1]["durationSeconds"] += delta
                sessions[-1]["durationMinutes"] = round(sessions[-1]["durationSeconds"] / 60.0, 2)
                sessions[-1]["endTime"] = now_str
                current_state["elapsedSeconds"] = sessions[-1]["durationSeconds"]
            else:
                if sessions:
                    prev = sessions[-1]
                    print(f"[{prev['endTime']} | {format_sec(prev['durationSeconds'])}] [{prev['category']}] {prev['appName']}  -->  {prev['windowTitle']}")

                new_sess = {
                    "id": f"local-{int(now * 1000)}",
                    "startTime": now_str,
                    "endTime": now_str,
                    "durationSeconds": delta,
                    "durationMinutes": round(delta / 60.0, 2),
                    "appName": app_name,
                    "processName": raw_app.lower().replace(" ", ""),
                    "siteOrModule": site_mod,
                    "windowTitle": raw_title,
                    "specificTask": task,
                    "category": cat,
                    "extractedTopics": topics,
                    "cognitiveDepth": "High" if cat in ["Deep Work", "Learning"] else "Low",
                    "contextSwitchesInBlock": 1,
                    "sourceType": "os-hook",
                    "inferredIntent": f"Active window: {task}"
                }
                sessions.append(new_sess)
                current_state["elapsedSeconds"] = delta
                print(f"[ACTIVE NOW | {cat}] {app_name}  -->  {raw_title}")

                payload_event = {
                    "appName": app_name,
                    "windowTitle": raw_title,
                    "deltaSeconds": delta,
                    "overrideCategory": cat,
                    "overrideTask": task,
                    "overrideTopics": topics,
                    "sourceType": "os-hook",
                    "localTime": now_str,
                    "localDate": datetime.now().strftime("%Y-%m-%d"),
                    "userToken": USER_TOKEN,
                    "deviceName": platform.node() or "Windows PC",
                    "os": f"{platform.system()} {platform.release()}",
                }
                ok = push_to_remote(payload_event)
                broadcast_ws(payload_event)
                if ok:
                    print(f"   [SYNC] Synced activity to ChronoTrace website ({SERVER_BASE})")

            current_state["appName"] = app_name
            current_state["windowTitle"] = raw_title
            current_state["specificTask"] = task
            current_state["category"] = cat
            current_state["timestamp"] = now

            if tick_count % 2 == 0:
                save_live_json()
                tick_payload = {
                    "appName": app_name,
                    "windowTitle": raw_title,
                    "deltaSeconds": 2,
                    "overrideCategory": cat,
                    "overrideTask": task,
                    "overrideTopics": topics,
                    "sourceType": "os-hook",
                    "localTime": now_str,
                    "localDate": datetime.now().strftime("%Y-%m-%d"),
                    "userToken": USER_TOKEN,
                    "deviceName": platform.node() or "Windows PC",
                    "os": f"{platform.system()} {platform.release()}",
                }
                push_to_remote(tick_payload)
                broadcast_ws(tick_payload)
        except Exception:
            pass

ws_clients = set()
ws_lock = threading.Lock()

def ws_handshake(key):
    magic = b"258EAFA5-E914-47DA-95CA-C5AB0DC85B11"
    sha1 = hashlib.sha1(key.encode("utf-8") + magic).digest()
    return base64.b64encode(sha1).decode("utf-8")

def make_ws_frame(message_bytes):
    length = len(message_bytes)
    if length <= 125:
        header = bytes([0x81, length])
    elif length <= 65535:
        header = struct.pack("!BBH", 0x81, 126, length)
    else:
        header = struct.pack("!BBQ", 0x81, 127, length)
    return header + message_bytes

def broadcast_ws(payload):
    try:
        msg_bytes = json.dumps(payload).encode("utf-8")
        frame = make_ws_frame(msg_bytes)
        with ws_lock:
            dead = []
            for client in list(ws_clients):
                try:
                    client.sendall(frame)
                except Exception:
                    dead.append(client)
            for d in dead:
                ws_clients.discard(d)
    except Exception:
        pass

class BridgeHandler(BaseHTTPRequestHandler):
    def _send_cors(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS, HEAD")
        self.send_header("Access-Control-Allow-Headers", "*")
        self.send_header("Access-Control-Allow-Private-Network", "true")

    def do_OPTIONS(self):
        self.send_response(204)
        self._send_cors()
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self):
        # Check for WebSocket Upgrade
        upgrade_hdr = self.headers.get("Upgrade", "")
        if upgrade_hdr.lower() == "websocket":
            key = self.headers.get("Sec-WebSocket-Key", "")
            if key:
                accept_val = ws_handshake(key.strip())
                self.send_response(101, "Switching Protocols")
                self.send_header("Upgrade", "websocket")
                self.send_header("Connection", "Upgrade")
                self.send_header("Sec-WebSocket-Accept", accept_val)
                self.end_headers()

                sock = self.request
                with ws_lock:
                    ws_clients.add(sock)
                print("   [BRIDGE] Connected to ChronoTrace website via Real-Time WebSocket!")

                # Send initial snapshot immediately
                init_msg = json.dumps({
                    "appName": current_state["appName"],
                    "windowTitle": current_state["windowTitle"],
                    "overrideTask": current_state.get("specificTask", current_state["windowTitle"]),
                    "overrideCategory": current_state.get("category", "Utility"),
                    "deltaSeconds": 1,
                    "userToken": USER_TOKEN,
                    "deviceName": platform.node() or "Windows PC",
                    "os": f"{platform.system()} {platform.release()}",
                    "heartbeat": True
                }).encode("utf-8")
                try:
                    sock.sendall(make_ws_frame(init_msg))
                except Exception:
                    pass

                # Keep connection alive, listen for ping/close
                try:
                    while True:
                        head = sock.recv(2)
                        if not head:
                            break
                        opcode = head[0] & 0x0f
                        if opcode == 0x8:
                            break
                        length = head[1] & 0x7f
                        if length == 126:
                            ext = sock.recv(2)
                            length = struct.unpack("!H", ext)[0]
                        elif length == 127:
                            ext = sock.recv(8)
                            length = struct.unpack("!Q", ext)[0]
                        mask = sock.recv(4) if (head[1] & 0x80) else None
                        if length > 0:
                            sock.recv(length)
                except Exception:
                    pass
                finally:
                    with ws_lock:
                        ws_clients.discard(sock)
                return

        # Regular HTTP response (JSON)
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self._send_cors()
        self.end_headers()
        payload = json.dumps({
            "status": "ok",
            "heartbeat": True,
            "userToken": USER_TOKEN,
            "deviceName": platform.node() or "Windows PC",
            "os": f"{platform.system()} {platform.release()}",
            "appName": current_state["appName"],
            "windowTitle": current_state["windowTitle"],
            "specificTask": current_state.get("specificTask", current_state["windowTitle"]),
            "category": current_state.get("category", "Utility"),
            "elapsedSeconds": current_state["elapsedSeconds"],
            "timestamp": current_state["timestamp"],
            "sessions": sessions
        }).encode("utf-8")
        self.wfile.write(payload)

    def log_message(self, format, *args):
        return

if __name__ == "__main__":
    print("================================================================")
    print("  ChronoTrace Activity Reconstruction Telemetry Agent")
    print(f"  Target Website: {SERVER_BASE}")
    print(f"  Live Bridge:    ws://127.0.0.1:{PORT} & http://127.0.0.1:{PORT}/live")
    if USER_TOKEN:
        masked_token = USER_TOKEN[:6] + "..." if len(USER_TOKEN) > 6 else USER_TOKEN
        print(f"  Device Token:   {masked_token} (Bound to User Account)")
    else:
        print("  Device Token:   None (Connecting as Default User)")
    print("  Status:         Passive monitoring running... Keep this window open.")
    print("================================================================\n")

    # Initial startup connection handshake
    push_to_remote({
        "heartbeat": True,
        "startup": True,
        "deviceName": platform.node() or "Windows Workstation",
        "os": f"{platform.system()} {platform.release()} ({platform.architecture()[0]})",
        "agentVersion": "1.3.0",
        "samplingInterval": "500ms"
    })

    t = threading.Thread(target=poll_os_loop, daemon=True)
    t.start()

    server = ThreadingHTTPServer(("0.0.0.0", PORT), BridgeHandler)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped ChronoTrace Agent.")
