import React, { useState, useMemo } from 'react';
import {
  Search,
  Filter,
  ChevronDown,
  ChevronUp,
  Clock,
  Laptop,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  Sparkles,
} from 'lucide-react';
import { ChunkSummary, IntentLabel } from '@shared/types/chronotrace';

interface ActivityTimelineViewProps {
  chunks: ChunkSummary[];
  onCorrectIntent?: (chunkId: string, newIntent: IntentLabel) => void;
  onOpenDeviceModal?: () => void;
}

export const ActivityTimelineView: React.FC<ActivityTimelineViewProps> = ({
  chunks,
  onCorrectIntent,
  onOpenDeviceModal,
}) => {
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [categoryFilter, setCategoryFilter] = useState<string>('ALL');
  const [appFilter, setAppFilter] = useState<string>('ALL');
  const [expandedChunkId, setExpandedChunkId] = useState<string | null>(null);

  // Filter out obsolete dummy seed chunks when real device sessions are recorded
  const liveChunks = useMemo(() => {
    if (!chunks || chunks.length === 0) return [];
    const hasLive = chunks.some(
      (c) => c.primary_task !== 'TS Assignment' && !c.summary?.includes('switch-case syntax')
    );
    if (hasLive) {
      return chunks.filter(
        (c) => c.primary_task !== 'TS Assignment' && !c.summary?.includes('switch-case syntax')
      );
    }
    return chunks;
  }, [chunks]);

  // Extract unique applications
  const uniqueApps = useMemo(() => {
    const apps = new Set<string>();
    liveChunks.forEach((c) => {
      if (c.anchor_app) apps.add(c.anchor_app);
      c.main_events?.forEach((e) => {
        if (e.app) apps.add(e.app);
      });
    });
    return Array.from(apps);
  }, [liveChunks]);

  // Filtering logic
  const filteredChunks = useMemo(() => {
    return liveChunks.filter((c) => {
      // Category filter
      if (categoryFilter !== 'ALL') {
        if (categoryFilter === 'FOCUS' && c.intent !== 'DEEP_WORK') return false;
        if (categoryFilter === 'LEARNING' && c.intent !== 'LEARNING') return false;
        if (
          categoryFilter === 'DISTRACTION' &&
          c.intent !== 'DISTRACTION' &&
          c.intent !== 'DISTRACTION_BREAK'
        )
          return false;
      }

      // App filter
      if (appFilter !== 'ALL') {
        const matchesAnchor = c.anchor_app?.toLowerCase().includes(appFilter.toLowerCase());
        const matchesSubEvent = c.main_events?.some((e) =>
          e.app.toLowerCase().includes(appFilter.toLowerCase())
        );
        if (!matchesAnchor && !matchesSubEvent) return false;
      }

      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchesTask = c.primary_task?.toLowerCase().includes(q);
        const matchesSummary = c.summary?.toLowerCase().includes(q);
        const matchesApp = c.anchor_app?.toLowerCase().includes(q);
        const matchesEvents = c.main_events?.some(
          (e) => e.title.toLowerCase().includes(q) || e.app.toLowerCase().includes(q)
        );
        if (!matchesTask && !matchesSummary && !matchesApp && !matchesEvents) return false;
      }

      return true;
    });
  }, [liveChunks, categoryFilter, appFilter, searchQuery]);

  // Format duration into readable text
  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.round(seconds % 60);
    if (mins > 0 && secs > 0) return `${mins}m ${secs}s`;
    if (mins > 0) return `${mins}m`;
    return `${secs}s`;
  };

  // Human category styling & labels
  const getCategoryDetails = (intent?: string) => {
    switch (intent) {
      case 'DEEP_WORK':
        return {
          label: 'Focus',
          textClass: 'text-emerald-700',
          dotClass: 'bg-emerald-500',
          bgClass: 'bg-emerald-50/60',
          borderClass: 'border-emerald-200',
        };
      case 'LEARNING':
        return {
          label: 'Learning',
          textClass: 'text-blue-700',
          dotClass: 'bg-blue-500',
          bgClass: 'bg-blue-50/60',
          borderClass: 'border-blue-200',
        };
      case 'DISTRACTION':
      case 'DISTRACTION_BREAK':
        return {
          label: 'Distraction',
          textClass: 'text-rose-700',
          dotClass: 'bg-rose-500',
          bgClass: 'bg-rose-50/60',
          borderClass: 'border-rose-200',
        };
      default:
        return {
          label: 'Needs review',
          textClass: 'text-slate-600',
          dotClass: 'bg-slate-400',
          bgClass: 'bg-slate-50',
          borderClass: 'border-slate-200',
        };
    }
  };

  const toggleExpand = (chunkId: string) => {
    setExpandedChunkId((prev) => (prev === chunkId ? null : chunkId));
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header and overview */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">Activity Timeline</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Chronological reconstruction of your computer activity grouped into meaningful work sessions
          </p>
        </div>

        <div className="text-xs text-slate-500 font-medium">
          Showing {filteredChunks.length} of {chunks.length} sessions
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-2xs space-y-3">
        <div className="flex flex-col sm:flex-row items-center gap-3">
          {/* Search Input */}
          <div className="relative flex-1 w-full">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by task, application, or window title..."
              className="w-full pl-9 pr-3 py-2 text-xs rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900 placeholder:text-slate-400"
            />
          </div>

          {/* Category Filter */}
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <div className="flex items-center gap-1.5 text-xs text-slate-500 shrink-0">
              <Filter className="w-3.5 h-3.5" />
              <span>Category:</span>
            </div>
            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="text-xs border border-slate-200 rounded-lg px-2.5 py-2 text-slate-700 bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer"
            >
              <option value="ALL">All Categories</option>
              <option value="FOCUS">Focus (Deep Work)</option>
              <option value="LEARNING">Learning</option>
              <option value="DISTRACTION">Distraction</option>
            </select>
          </div>

          {/* Application Filter */}
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <select
              value={appFilter}
              onChange={(e) => setAppFilter(e.target.value)}
              className="text-xs border border-slate-200 rounded-lg px-2.5 py-2 text-slate-700 bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer"
            >
              <option value="ALL">All Applications</option>
              {uniqueApps.map((app) => (
                <option key={app} value={app}>
                  {app}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Timeline Stream */}
      {chunks.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-xl p-12 text-center max-w-lg mx-auto shadow-xs">
          <Clock className="w-10 h-10 text-slate-300 mx-auto mb-3" />
          <h3 className="text-sm font-bold text-slate-900">No activity sessions recorded yet</h3>
          <p className="text-xs text-slate-500 mt-1.5 leading-relaxed">
            ChronoTrace groups continuous foreground window dwell and transitions into meaningful cognitive focus sessions. Run the Windows telemetry agent to begin reconstructing your work day.
          </p>
          {onOpenDeviceModal && (
            <button
              onClick={onOpenDeviceModal}
              className="mt-4 inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white shadow-xs transition-colors cursor-pointer"
            >
              <Laptop className="w-3.5 h-3.5" />
              <span>Connect Device</span>
            </button>
          )}
        </div>
      ) : filteredChunks.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-xl p-12 text-center">
          <HelpCircle className="w-8 h-8 text-slate-300 mx-auto mb-2" />
          <h3 className="text-sm font-semibold text-slate-900">No sessions match your filter</h3>
          <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
            Try adjusting your search terms, application selection, or category filters.
          </p>
          <button
            onClick={() => {
              setSearchQuery('');
              setCategoryFilter('ALL');
              setAppFilter('ALL');
            }}
            className="mt-4 text-xs font-medium text-blue-600 hover:text-blue-700 cursor-pointer"
          >
            Clear all filters
          </button>
        </div>
      ) : (
        <div className="relative pl-6 sm:pl-8 space-y-4 before:absolute before:left-3 sm:before:left-4 before:top-3 before:bottom-3 before:w-0.5 before:bg-slate-200">
          {filteredChunks.map((chunk, idx) => {
            const cat = getCategoryDetails(chunk.intent);
            const isExpanded = expandedChunkId === chunk.chunk_id;
            const confidence = chunk.confidence ? Math.round(chunk.confidence * 100) : null;
            const isUncertain = !confidence || confidence < 65;

            return (
              <div key={chunk.chunk_id || idx} className="relative group">
                {/* Timeline node icon on vertical line */}
                <div
                  className={`absolute -left-6 sm:-left-8 top-4 w-5 h-5 rounded-full border-2 border-white flex items-center justify-center shadow-xs ${cat.dotClass}`}
                />

                {/* Main Session Card */}
                <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-2xs hover:border-slate-300 transition-colors">
                  <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                    <div className="space-y-1.5 flex-1">
                      {/* Quiet unboxed metadata header */}
                      <div className="flex flex-wrap items-center gap-2 text-xs">
                        <span className="font-mono font-semibold text-slate-900">
                          {chunk.start_time} - {chunk.end_time}
                        </span>
                        {chunk.recorded_at && (
                          <>
                            <span className="text-slate-300" aria-hidden="true">
                              ·
                            </span>
                            <span className="text-slate-500 font-medium">
                              {new Date(chunk.recorded_at).toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' })}
                            </span>
                          </>
                        )}
                        <span className="text-slate-300" aria-hidden="true">
                          ·
                        </span>
                        <span className="font-medium text-slate-700">
                          {formatDuration(chunk.duration_s)}
                        </span>
                        <span className="text-slate-300" aria-hidden="true">
                          ·
                        </span>
                        <span className={`font-semibold ${cat.textClass}`}>{cat.label}</span>
                        <span className="text-slate-300" aria-hidden="true">
                          ·
                        </span>
                        {isUncertain ? (
                          <span className="text-amber-600 font-medium">Needs review</span>
                        ) : (
                          <span className="text-slate-500">{confidence}% confidence</span>
                        )}
                      </div>

                      {/* Title & Primary Task */}
                      <h3 className="text-base font-semibold text-slate-900 pt-0.5">
                        {chunk.primary_task || chunk.anchor_app || 'Activity Session'}
                      </h3>

                      {/* Natural language summary */}
                      <p className="text-xs text-slate-600 leading-relaxed max-w-3xl">
                        {chunk.summary ||
                          'Observed active foreground work window transitions during this interval.'}
                      </p>
                    </div>

                    {/* Expand/Collapse Button */}
                    <button
                      onClick={() => toggleExpand(chunk.chunk_id)}
                      className="inline-flex items-center gap-1.5 text-xs text-slate-600 hover:text-slate-900 font-medium px-2.5 py-1.5 rounded-lg hover:bg-slate-50 transition-colors border border-slate-200 cursor-pointer self-start shrink-0"
                    >
                      <span>{isExpanded ? 'Hide Details' : 'View Sub-events'}</span>
                      {isExpanded ? (
                        <ChevronUp className="w-3.5 h-3.5 text-slate-400" />
                      ) : (
                        <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
                      )}
                    </button>
                  </div>

                  {/* Expandable sub-events drawer */}
                  {isExpanded && (
                    <div className="mt-4 pt-4 border-t border-slate-100 space-y-3">
                      <div className="text-xs font-semibold text-slate-800 flex items-center gap-1.5">
                        <Laptop className="w-3.5 h-3.5 text-slate-500" />
                        <span>Windows Transitions in this Session</span>
                      </div>

                      <div className="space-y-1.5">
                        {chunk.main_events && chunk.main_events.length > 0 ? (
                          chunk.main_events.map((evt, eIdx) => (
                            <div
                              key={eIdx}
                              className="p-2.5 rounded-lg bg-slate-50 border border-slate-100 flex items-center justify-between text-xs"
                            >
                              <div className="flex items-center gap-2 truncate">
                                <span className="font-semibold text-slate-800 shrink-0">
                                  {evt.app}:
                                </span>
                                <span className="text-slate-600 truncate">{evt.title}</span>
                              </div>
                              <span className="text-slate-500 font-mono text-[11px] shrink-0 ml-3">
                                {Math.round(evt.dwell_s)}s dwell
                              </span>
                            </div>
                          ))
                        ) : (
                          <div className="text-xs text-slate-400 italic">
                            Continuous session in primary window.
                          </div>
                        )}
                      </div>

                      {/* Unresolved threads / tasks */}
                      {chunk.unresolved_threads && chunk.unresolved_threads.length > 0 && (
                        <div className="mt-3 p-3 rounded-lg bg-blue-50/60 border border-blue-100 text-xs">
                          <div className="font-semibold text-blue-900 mb-1">
                            Unresolved Task Items
                          </div>
                          <ul className="list-disc list-inside text-blue-800 space-y-0.5">
                            {chunk.unresolved_threads.map((thread, tIdx) => (
                              <li key={tIdx}>{thread}</li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
