import React, { useState, useEffect } from 'react';
import {
  Laptop,
  CheckCircle2,
  X,
  RefreshCw,
  Terminal,
  Copy,
  Check,
  Download,
  AlertCircle,
  Shield,
  XCircle,
  Radio,
  FileCode,
  Square,
  ClipboardPaste,
} from 'lucide-react';
import { DeviceState } from '@shared/types/chronotrace';

interface DeviceModalProps {
  device: DeviceState | null;
  onClose: () => void;
  onRefresh: () => void;
  userToken?: string;
  liveFileActive?: boolean;
  onSetLiveFileHandle?: (handle: any) => void;
  onStopLiveStream?: () => void;
}

const formatDateTime = (iso?: string | null) => {
  if (!iso) return 'Never';
  try {
    const d = new Date(iso);
    return isNaN(d.getTime())
      ? 'Never'
      : d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }) + ', ' + d.toLocaleDateString();
  } catch {
    return 'Never';
  }
};

export const DeviceModal: React.FC<DeviceModalProps> = ({
  device,
  onClose,
  onRefresh,
  userToken,
  liveFileActive = false,
  onSetLiveFileHandle,
  onStopLiveStream,
}) => {
  const [testing, setTesting] = useState(false);
  const [copiedManual, setCopiedManual] = useState(false);
  const [copiedClipCmd, setCopiedClipCmd] = useState(false);
  const [message, setMessage] = useState<{ text: string; success: boolean } | null>(null);
  const [syncingFile, setSyncingFile] = useState(false);

  const isConnected = device?.connected === true || liveFileActive;

  // Auto-refresh status while modal is open
  useEffect(() => {
    const interval = setInterval(() => {
      onRefresh();
    }, 1500);

    return () => clearInterval(interval);
  }, [onRefresh]);

  // Connect live streaming file using File System Access API (Chrome/Edge/Opera)
  const handleConnectLiveFile = async () => {
    setMessage(null);
    try {
      if ('showOpenFilePicker' in window) {
        const [handle] = await (window as any).showOpenFilePicker({
          types: [
            {
              description: 'ChronoTrace Live Activity File',
              accept: { 'application/json': ['.json'] },
            },
          ],
          multiple: false,
        });

        // Read file immediately
        const file = await handle.getFile();
        const text = await file.text();
        const parsed = JSON.parse(text);

        const res = await fetch('/api/agent/sync-file', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            sessions: parsed.sessions || [],
            current: parsed.current,
            userToken,
            deviceName: parsed.deviceName || 'Windows Workstation',
            os: parsed.os,
          }),
        });
        const data = await res.json();

        if (onSetLiveFileHandle) {
          onSetLiveFileHandle(handle);
        }

        onRefresh();
        setMessage({
          text: `Live streaming connected! Synced ${data.syncedSessions || 0} activity sessions from ${file.name}. Future window switches will update automatically.`,
          success: true,
        });
      } else {
        // Fallback for browsers without showOpenFilePicker
        const fileInput = document.getElementById('manual-json-file-input');
        if (fileInput) fileInput.click();
      }
    } catch (err: any) {
      if (err.name !== 'AbortError') {
        setMessage({
          text: `Could not link live file: ${err.message || 'Permission denied'}`,
          success: false,
        });
      }
    }
  };

  const handleManualFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setSyncingFile(true);
    setMessage(null);
    try {
      const text = await file.text();
      const parsed = JSON.parse(text);
      const res = await fetch('/api/agent/sync-file', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessions: parsed.sessions || [],
          current: parsed.current,
          userToken,
          deviceName: parsed.deviceName || 'Windows Workstation',
          os: parsed.os,
        }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        onRefresh();
        setMessage({
          text: `Successfully synced ${data.syncedSessions || 0} activities from ${file.name}!`,
          success: true,
        });
      } else {
        throw new Error(data.error || 'Failed to sync activity file');
      }
    } catch (err: any) {
      setMessage({
        text: `Error reading file: ${err.message || 'Invalid JSON format'}`,
        success: false,
      });
    } finally {
      setSyncingFile(false);
      e.target.value = '';
    }
  };

  const handleClipboardSync = async () => {
    setMessage(null);
    try {
      const clipText = await navigator.clipboard.readText();
      if (!clipText || !clipText.trim().startsWith('{') && !clipText.trim().startsWith('[')) {
        setMessage({
          text: 'Clipboard does not contain valid JSON. Run the copy command in PowerShell first.',
          success: false,
        });
        return;
      }
      const parsed = JSON.parse(clipText);
      const res = await fetch('/api/agent/sync-file', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessions: parsed.sessions || [],
          current: parsed.current,
          userToken,
          deviceName: parsed.deviceName || 'Windows Workstation',
          os: parsed.os,
        }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        onRefresh();
        setMessage({
          text: `Successfully synced ${data.syncedSessions || 0} activities from clipboard!`,
          success: true,
        });
      } else {
        throw new Error(data.error || 'Failed to sync clipboard data');
      }
    } catch (err: any) {
      setMessage({
        text: `Clipboard sync error: ${err.message || 'Could not access clipboard'}`,
        success: false,
      });
    }
  };

  const copyClipCmd = () => {
    navigator.clipboard.writeText('Get-Content ~/chronotrace_live.json -Raw | Set-Clipboard');
    setCopiedClipCmd(true);
    setTimeout(() => setCopiedClipCmd(false), 2000);
  };

  const copyManual = () => {
    navigator.clipboard.writeText('cd "$env:USERPROFILE\\Downloads"; python chronotrace_agent.py');
    setCopiedManual(true);
    setTimeout(() => setCopiedManual(false), 2000);
  };

  const handleDownload = async (e: React.MouseEvent) => {
    e.preventDefault();
    try {
      const tokenParam = userToken ? `?token=${encodeURIComponent(userToken)}` : '';
      const res = await fetch(`/api/download-agent${tokenParam}`);
      if (!res.ok) throw new Error('Download failed');
      const text = await res.text();
      const blob = new Blob([text], { type: 'text/x-python' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'chronotrace_agent.py';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch {
      window.location.href = `/api/download-agent`;
    }
  };

  const handleTestConnection = async () => {
    setTesting(true);
    setMessage(null);
    try {
      const res = await fetch('/api/device/connect', { method: 'POST' });
      const data = await res.json();
      onRefresh();
      if (data.connected || isConnected) {
        setMessage({
          text: 'Connection verified! Active heartbeats and telemetry are streaming live.',
          success: true,
        });
      } else {
        setMessage({
          text: 'No active telemetry received yet. Please connect your live file or keep PowerShell open.',
          success: false,
        });
      }
    } catch {
      setMessage({
        text: 'Could not reach server. Check network connection.',
        success: false,
      });
    } finally {
      setTesting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 p-4">
      <div className="bg-white border border-slate-200 rounded-2xl max-w-lg w-full p-6 shadow-xl relative animate-in fade-in zoom-in-95 duration-150 max-h-[92vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <Laptop className="w-5 h-5 text-blue-600" />
            <h3 className="font-bold text-slate-900 text-sm">Windows Device Connection</h3>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1 rounded cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="space-y-4 my-4 text-xs">
          {/* Status Card */}
          <div
            className={`p-4 rounded-xl border flex flex-col gap-2.5 transition-colors ${
              isConnected
                ? 'bg-emerald-50/70 border-emerald-300'
                : device?.status === 'DISCONNECTED'
                ? 'bg-amber-50/50 border-amber-200'
                : 'bg-slate-50 border-slate-200'
            }`}
          >
            <div className="flex items-center justify-between">
              <div>
                <div className="font-bold text-slate-900 text-sm">
                  {device?.deviceName || 'Windows Workstation'}
                </div>
                <div className="text-slate-500 text-[11px]">
                  {device?.os || 'Windows 11 64-bit'} · Agent v{device?.agentVersion || '1.3.0'}
                </div>
              </div>

              {isConnected ? (
                <div className="flex items-center gap-2">
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-semibold bg-emerald-100 text-emerald-800 border border-emerald-300 shadow-2xs">
                    <span className="w-2 h-2 rounded-full bg-emerald-600 animate-pulse" />
                    {liveFileActive
                      ? 'Connected · Live Stream Active'
                      : device?.eventCount && device.eventCount > 0
                      ? 'Connected · Receiving Events'
                      : 'Connected · Awaiting Activity'}
                  </span>
                  {liveFileActive && (
                    <button
                      type="button"
                      onClick={onStopLiveStream}
                      title="Stop Live Stream"
                      className="p-1 rounded-md text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                    >
                      <Square className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              ) : device?.status === 'DISCONNECTED' ? (
                <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-semibold bg-amber-100 text-amber-800 border border-amber-300">
                  <AlertCircle className="w-3 h-3 text-amber-600" />
                  Disconnected · Agent Offline
                </span>
              ) : (
                <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-semibold bg-slate-200 text-slate-700 border border-slate-300">
                  <XCircle className="w-3 h-3 text-slate-500" />
                  Not Connected
                </span>
              )}
            </div>

            <div className="flex items-center justify-between text-[11px] text-slate-500 pt-2 border-t border-slate-200/70">
              <span>
                Last Heartbeat:{' '}
                <strong className="font-medium text-slate-700">
                  {formatDateTime(device?.lastHeartbeatAt)}
                </strong>
              </span>
              <span>
                Events Today:{' '}
                <strong className="font-medium text-slate-700">{device?.eventCount || 0}</strong>
              </span>
            </div>
          </div>

          {/* Feedback Message */}
          {message && (
            <div
              className={`p-3 rounded-xl border text-xs flex items-start gap-2 ${
                message.success
                  ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                  : 'bg-amber-50 border-amber-200 text-amber-800'
              }`}
            >
              {message.success ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              ) : (
                <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              )}
              <span className="font-medium leading-relaxed">{message.text}</span>
            </div>
          )}

          {/* PRIMARY LIVE STREAM BRIDGE ACTION */}
          <div className="p-4 rounded-xl border-2 border-blue-400 bg-blue-50/60 shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Radio className="w-4 h-4 text-blue-600 animate-pulse" />
                <span className="font-bold text-blue-950 text-xs">
                  Activity Running in PowerShell?
                </span>
              </div>
              <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-100 border border-emerald-300 px-2 py-0.5 rounded-full">
                Real-Time Streaming
              </span>
            </div>

            <p className="text-[11px] text-blue-900/80 leading-relaxed">
              Your PowerShell agent records every window switch to <code>~/chronotrace_live.json</code>.
              Connect this file once to stream your live foreground activity directly into the website!
            </p>

            <div className="flex items-center gap-2 pt-1">
              <button
                type="button"
                onClick={handleConnectLiveFile}
                className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold transition-all cursor-pointer text-xs shadow-sm hover:shadow"
              >
                <Radio className="w-3.5 h-3.5" />
                <span>{liveFileActive ? 'Live Stream Active (Watching File)' : 'Connect Live Activity File'}</span>
              </button>

              <label className="inline-flex items-center gap-1.5 px-3 py-2.5 rounded-xl bg-white border border-slate-300 hover:bg-slate-50 text-slate-700 font-medium transition-colors cursor-pointer text-xs shrink-0 shadow-2xs">
                <FileCode className="w-3.5 h-3.5 text-blue-600" />
                <span>{syncingFile ? 'Syncing...' : 'Import .json'}</span>
                <input
                  id="manual-json-file-input"
                  type="file"
                  accept=".json"
                  onChange={handleManualFileUpload}
                  disabled={syncingFile}
                  className="hidden"
                />
              </label>
            </div>
          </div>

          {/* Alternative 1-Click Clipboard Sync */}
          <div className="p-3.5 rounded-xl border border-slate-200 bg-slate-50/70 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-slate-800 text-xs flex items-center gap-1.5">
                <ClipboardPaste className="w-3.5 h-3.5 text-slate-600" />
                Alternative: 1-Click Clipboard Sync
              </span>
            </div>
            <p className="text-[11px] text-slate-500">
              Run this in PowerShell to copy the latest activity, then click Paste:
            </p>
            <div className="flex items-center gap-2">
              <div className="flex-1 p-2 bg-slate-900 text-emerald-400 font-mono text-[10px] rounded-lg break-all select-all">
                Get-Content ~/chronotrace_live.json -Raw | Set-Clipboard
              </div>
              <button
                type="button"
                onClick={copyClipCmd}
                className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white text-[10px] font-medium transition-colors cursor-pointer border border-slate-700 shrink-0"
              >
                {copiedClipCmd ? 'Copied!' : 'Copy Cmd'}
              </button>
              <button
                type="button"
                onClick={handleClipboardSync}
                className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-[10px] font-semibold transition-colors cursor-pointer shrink-0 shadow-2xs"
              >
                Paste & Sync
              </button>
            </div>
          </div>

          {/* Setup Steps (Download & Run) */}
          <div className="p-3.5 rounded-xl border border-slate-200 bg-slate-50/60 space-y-2.5">
            <span className="font-semibold text-slate-800 text-xs block">
              How to Start the Python Agent
            </span>

            <div className="space-y-2">
              {/* Step 1 */}
              <div className="bg-white p-2.5 rounded-lg border border-slate-200 flex items-center justify-between gap-2">
                <div>
                  <div className="font-semibold text-slate-800 text-[11px]">
                    Step 1: Download Agent File
                  </div>
                  <div className="text-[10px] text-slate-500">
                    Saves to Downloads with standard-library passive monitoring.
                  </div>
                </div>
                <button
                  type="button"
                  onClick={handleDownload}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-900 text-white font-medium transition-colors cursor-pointer text-xs shrink-0 shadow-2xs"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download .py</span>
                </button>
              </div>

              {/* Step 2 */}
              <div className="bg-white p-2.5 rounded-lg border border-slate-200 space-y-1">
                <div className="font-semibold text-slate-800 text-[11px]">
                  Step 2: Run in PowerShell or Command Prompt
                </div>
                <div className="relative group mt-1">
                  <div className="p-2 bg-slate-900 text-emerald-400 font-mono text-[10px] rounded-lg break-all select-all pr-16">
                    cd "$env:USERPROFILE\Downloads"; python chronotrace_agent.py
                  </div>
                  <button
                    type="button"
                    onClick={copyManual}
                    className="absolute right-1.5 top-1.5 inline-flex items-center gap-1 px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-white text-[10px] font-medium transition-colors cursor-pointer border border-slate-700"
                  >
                    {copiedManual ? (
                      <>
                        <Check className="w-3 h-3 text-emerald-400" />
                        <span className="text-emerald-400">Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3" />
                        <span>Copy</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Privacy Note */}
          <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/80 flex items-start gap-2 text-[11px] text-slate-600">
            <Shield className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
            <span>
              Passive monitoring only. Collects active window titles and dwell seconds. No keylogging, screenshots, or camera access.
            </span>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="flex items-center justify-between pt-3 border-t border-slate-100">
          <button
            type="button"
            onClick={handleTestConnection}
            disabled={testing}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white transition-colors cursor-pointer disabled:opacity-60 shadow-xs"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${testing ? 'animate-spin' : ''}`} />
            <span>{testing ? 'Checking...' : 'Check Connection'}</span>
          </button>

          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-xs font-medium text-slate-600 hover:bg-slate-100 transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

