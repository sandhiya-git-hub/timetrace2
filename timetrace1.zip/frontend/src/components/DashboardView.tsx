import React, { useState, useEffect, useMemo } from 'react';
import { DateRangePicker, DateRangeSelection } from './DateRangePicker';
import {
  DailySynthesis,
  ChunkSummary,
  ReentryBriefing,
  UserProfile,
  TelemetryEvent,
  DeviceState,
} from '@shared/types/chronotrace';
import {
  Laptop,
  AlertCircle,
  CheckCircle2,
  XCircle,
  RefreshCw,
  ArrowRight,
  Shield,
  HelpCircle,
  Sparkles,
  Clock,
  Compass,
  Radio,
} from 'lucide-react';

interface DashboardViewProps {
  user: UserProfile | null;
  device?: DeviceState | null;
  summary: DailySynthesis | null;
  chunks: ChunkSummary[];
  events?: TelemetryEvent[];
  reentry: ReentryBriefing | null;
  onRefreshSummary?: () => void;
  isSynthesizing?: boolean;
  onNavigateToTimeline?: () => void;
  onNavigateToAssistant?: (prompt?: string) => void;
  onOpenDeviceModal?: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  user,
  device,
  summary: initialSummary,
  chunks = [],
  events = [],
  reentry,
  onRefreshSummary,
  isSynthesizing,
  onNavigateToTimeline,
  onNavigateToAssistant,
  onOpenDeviceModal,
}) => {
  const [hoveredEvent, setHoveredEvent] = useState<string | null>(null);

  const displayEvents = useMemo(() => {
    if (!events || events.length === 0) return [];
    return events;
  }, [events]);

  const totalDwell = useMemo(() => {
    return displayEvents.reduce((acc, e) => acc + (e.dwell_ms || 2000), 0);
  }, [displayEvents]);

  const hasData = displayEvents.length > 0 || chunks.length > 0;
  const isDeviceConnected = device?.connected === true;
  const hasIncomingEvents = displayEvents.length > 0;

  // Real current date from live events, server synthesis, or browser locale
  const initialDateStr = useMemo(() => {
    if (initialSummary?.date) return initialSummary.date;
    if (displayEvents.length > 0) {
      const last = displayEvents[displayEvents.length - 1];
      if (last.date) return last.date;
      if (last.recorded_at) return new Date(last.recorded_at).toLocaleDateString('en-CA');
    }
    return new Date().toLocaleDateString('en-CA');
  }, [initialSummary, displayEvents]);

  const [dateRange, setDateRange] = useState<DateRangeSelection>({
    type: 'today',
    label: 'Today',
    startDate: initialDateStr,
    endDate: initialDateStr,
  });

  const [activeSummary, setActiveSummary] = useState<any>(initialSummary);
  const [isFetching, setIsFetching] = useState<boolean>(false);

  // Sync initial summary if provided
  useEffect(() => {
    if (initialSummary && dateRange.type === 'today') {
      setActiveSummary(initialSummary);
    }
  }, [initialSummary]);

  // Keep date aligned with actual event dates
  useEffect(() => {
    if (initialDateStr && dateRange.type === 'today') {
      setDateRange((prev) => ({
        ...prev,
        startDate: initialDateStr,
        endDate: initialDateStr,
      }));
    }
  }, [initialDateStr]);

  const handleDateRangeChange = async (newRange: DateRangeSelection) => {
    setDateRange(newRange);
    setIsFetching(true);
    try {
      const params = new URLSearchParams({
        range: newRange.type,
        ...(newRange.startDate && { startDate: newRange.startDate }),
        ...(newRange.endDate && { endDate: newRange.endDate }),
      });
      const res = await fetch(`/api/summary?${params.toString()}`);
      if (res.ok) {
        const data = await res.json();
        setActiveSummary(data);
      }
    } catch (err) {
      console.error('Error fetching summary for range:', err);
    } finally {
      setIsFetching(false);
    }
  };

  const getSegmentColor = (cat: string) => {
    switch (cat) {
      case 'Deep Work':
        return '#334155'; // dark slate
      case 'Learning':
        return '#22c55e'; // green
      case 'Distraction':
        return '#ef4444'; // red
      case 'Ambient':
        return '#3b82f6'; // blue
      case 'Restless':
        return '#f59e0b'; // amber
      case 'Utility':
        return '#06b6d4'; // cyan
      default:
        return '#64748b';
    }
  };

  const formatSec = (seconds: number = 0) => {
    if (seconds <= 0) return '0s';
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    if (mins > 0 && secs > 0) return `${mins}m ${secs}s`;
    if (mins > 0) return `${mins}m`;
    return `${secs}s`;
  };

  const deepWorkSec = activeSummary?.total_deep_work_s ?? 0;
  const distractionSec = activeSummary?.total_distraction_s ?? 0;
  const switches = activeSummary?.context_switches ?? 0;
  const totalSec = activeSummary?.total_telemetry_s ?? (deepWorkSec + distractionSec);

  const workState = hasData
    ? activeSummary?.work_state || (distractionSec > deepWorkSec ? 'UNSETTLED' : 'PRODUCTIVE')
    : 'AWAITING ACTIVITY';

  const deepSub = hasData
    ? deepWorkSec > 0
      ? `— ${formatSec(deepWorkSec)} focused work & research`
      : 'No deep work recorded yet'
    : 'No data yet';

  const distSub = hasData
    ? distractionSec > 0
      ? `↓ ${formatSec(distractionSec)} distraction dwell`
      : '0s recorded distraction'
    : 'No data yet';

  const switchSub = hasData
    ? switches > 0
      ? `— ${switches} window transitions detected`
      : '— Active telemetry stream'
    : '0 transitions recorded';

  const workStateSub = hasData
    ? totalSec === 0
      ? 'Waiting for Windows agent activity'
      : workState === 'PRODUCTIVE'
      ? `↑ Deep Work (${formatSec(deepWorkSec)}) > Distraction (${formatSec(distractionSec)})`
      : `↓ Distraction (${formatSec(distractionSec)}) > Deep Work (${formatSec(deepWorkSec)})`
    : 'Run Windows agent to begin tracking';

  // Compute 7-day focus vs distraction dynamically from real events
  const weeklyDaysComputed = useMemo(() => {
    const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const map = new Map<string, { deep: number; dist: number }>();
    days.forEach((d) => map.set(d, { deep: 0, dist: 0 }));

    displayEvents.forEach((ev) => {
      let dayName = 'Today';
      if (ev.recorded_at) {
        const dateObj = new Date(ev.recorded_at);
        if (!isNaN(dateObj.getTime())) {
          dayName = days[dateObj.getDay()];
        }
      }
      const entry = map.get(dayName) || { deep: 0, dist: 0 };
      const sec = Math.round((ev.dwell_ms || 2000) / 1000);
      if (ev.category === 'Deep Work' || ev.category === 'Learning') {
        entry.deep += Math.round(sec / 60);
      } else if (ev.category === 'Distraction' || ev.category === 'Entertainment') {
        entry.dist += Math.round(sec / 60);
      }
      map.set(dayName, entry);
    });

    const currentDayIdx = new Date().getDay();
    const orderedDays = [];
    for (let i = 6; i >= 0; i--) {
      const idx = (currentDayIdx - i + 7) % 7;
      const d = days[idx];
      const val = map.get(d) || { deep: 0, dist: 0 };
      orderedDays.push({ day: d, deep: val.deep, dist: val.dist });
    }
    return orderedDays;
  }, [displayEvents]);

  // Compute 7x24 heatmap from real event hours
  const heatmapComputed = useMemo(() => {
    const grid: number[][] = Array.from({ length: 7 }, () => Array(24).fill(0));
    if (displayEvents.length === 0) return grid;

    displayEvents.forEach((ev) => {
      let h = 12;
      let d = 0;
      if (ev.recorded_at) {
        const dObj = new Date(ev.recorded_at);
        if (!isNaN(dObj.getTime())) {
          h = dObj.getHours();
          d = dObj.getDay();
        }
      } else if (ev.timestamp) {
        const parts = ev.timestamp.split(':');
        if (parts.length >= 1) {
          const parsedH = parseInt(parts[0], 10);
          if (!isNaN(parsedH)) h = parsedH % 24;
        }
      }
      const isDeep = ev.category === 'Deep Work' || ev.category === 'Learning';
      const weight = isDeep ? 0.35 : 0.15;
      grid[d % 7][h % 24] = Math.min(1, grid[d % 7][h % 24] + weight);
    });
    return grid;
  }, [displayEvents]);

  return (
    <div className="space-y-4 pb-12 font-sans text-slate-800">
      {/* ─── COMPACT DEVICE STATUS INDICATOR IN DASHBOARD HEADER ─── */}
      <div
        className={`p-4 rounded-2xl border transition-all shadow-xs ${
          isDeviceConnected
            ? hasIncomingEvents
              ? 'border-emerald-300 bg-emerald-50/50'
              : 'border-emerald-200 bg-emerald-50/30'
            : hasData
            ? 'border-amber-200 bg-amber-50/40'
            : 'border-slate-200 bg-white'
        }`}
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3.5">
          <div className="flex items-start sm:items-center gap-3">
            <div
              className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                isDeviceConnected
                  ? 'bg-emerald-600 text-white'
                  : hasData
                  ? 'bg-amber-100 text-amber-700'
                  : 'bg-blue-50 text-blue-600 border border-blue-200'
              }`}
            >
              <Laptop className="w-5 h-5 stroke-[2]" />
            </div>

            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                  Windows device
                </span>
                <span className="text-slate-300">·</span>
                <span className="text-xs text-slate-600 font-medium">Activity collection status:</span>

                {/* Explicit Status Badge */}
                {isDeviceConnected ? (
                  hasIncomingEvents ? (
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-100 text-emerald-800 border border-emerald-300">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 animate-pulse" />
                      Connected · Receiving events
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                      Connected · Waiting for activity
                    </span>
                  )
                ) : hasData ? (
                  <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-amber-100 text-amber-800 border border-amber-300">
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-600" />
                    Disconnected
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-slate-100 text-slate-700 border border-slate-300">
                    <span className="w-1.5 h-1.5 rounded-full bg-slate-400" />
                    Not connected
                  </span>
                )}
              </div>

              {/* Status Explanation Sentence */}
              <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                {isDeviceConnected
                  ? hasIncomingEvents
                    ? `Active telemetry stream from ${device?.deviceName || 'Windows Workstation'}. Reconstructing foreground window dwell and focus sessions in real time.`
                    : `Agent heartbeat confirmed. Waiting for the first window transition on ${device?.deviceName || 'Windows Workstation'}.`
                  : hasData
                  ? 'Your previous activity remains available. Connect your device whenever you want to record new activity.'
                  : 'Welcome to ChronoTrace. Connect your Windows device to begin passively reconstructing your work sessions.'}
              </p>
            </div>
          </div>

          {/* Action button */}
          <button
            type="button"
            onClick={onOpenDeviceModal}
            className={`inline-flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold shadow-xs transition-colors cursor-pointer shrink-0 ${
              isDeviceConnected
                ? 'bg-white hover:bg-slate-50 text-slate-700 border border-slate-300'
                : 'bg-blue-600 hover:bg-blue-700 text-white'
            }`}
          >
            {isDeviceConnected ? (
              <>
                <Laptop className="w-3.5 h-3.5 text-slate-500" />
                <span>Device Details</span>
              </>
            ) : hasData ? (
              <>
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Connect device</span>
              </>
            ) : (
              <>
                <span>Connect device</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </>
            )}
          </button>
        </div>
      </div>

      {/* ─── TOP BAR WITH DATE RANGE PICKER ─── */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-1">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900 leading-none">
            Analytics Overview
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Real-time passive telemetry reconstruction &amp; cognitive behavior stream
          </p>
        </div>

        {/* Date Range Picker */}
        <div className="flex items-center gap-2">
          <DateRangePicker
            value={dateRange}
            onChange={handleDateRangeChange}
            isLoading={isFetching}
          />
        </div>
      </div>

      {/* ─── 1. TOP STAT ROW (GRID 4) ─── */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
        {/* Card 1: Sustained Deep Work */}
        <div className={`bg-white border border-slate-200/90 rounded-xl p-4 shadow-xs transition-opacity duration-200 ${isFetching ? 'opacity-60' : 'opacity-100'}`}>
          <div className="text-xs text-slate-500 font-medium">Sustained Deep Work</div>
          <div className="text-3xl font-bold text-blue-600 mt-1 tracking-tight font-sans">
            {hasData ? formatSec(deepWorkSec) : '0s'}
          </div>
          <div className="text-xs text-slate-400 mt-1.5 flex items-center gap-1 font-normal truncate" title={deepSub}>
            <span>{deepSub}</span>
          </div>
        </div>

        {/* Card 2: Distraction Time */}
        <div className={`bg-white border border-slate-200/90 rounded-xl p-4 shadow-xs transition-opacity duration-200 ${isFetching ? 'opacity-60' : 'opacity-100'}`}>
          <div className="text-xs text-slate-500 font-medium">Distraction Time</div>
          <div className="text-3xl font-bold text-red-600 mt-1 tracking-tight font-sans">
            {hasData ? formatSec(distractionSec) : '0s'}
          </div>
          <div className="text-xs text-red-600/90 mt-1.5 flex items-center gap-1 font-normal truncate" title={distSub}>
            <span>{distSub}</span>
          </div>
        </div>

        {/* Card 3: Context Switches */}
        <div className={`bg-white border border-slate-200/90 rounded-xl p-4 shadow-xs transition-opacity duration-200 ${isFetching ? 'opacity-60' : 'opacity-100'}`}>
          <div className="text-xs text-slate-500 font-medium">Context Switches</div>
          <div className="text-3xl font-bold text-amber-600 mt-1 tracking-tight font-sans">
            {hasData ? switches : '0'}
          </div>
          <div className="text-xs text-slate-400 mt-1.5 flex items-center gap-1 font-normal truncate" title={switchSub}>
            <span>{switchSub}</span>
          </div>
        </div>

        {/* Card 4: Work State */}
        <div className={`bg-white border border-slate-200/90 rounded-xl p-4 shadow-xs transition-opacity duration-200 ${isFetching ? 'opacity-60' : 'opacity-100'}`}>
          <div className="text-xs text-slate-500 font-medium">Work State</div>
          <div className={`text-2xl font-bold mt-1.5 tracking-tight font-sans uppercase ${
            workState === 'PRODUCTIVE'
              ? 'text-emerald-600'
              : workState === 'AWAITING ACTIVITY'
              ? 'text-slate-400'
              : 'text-amber-600'
          }`}>
            {workState}
          </div>
          <div className={`text-xs mt-1.5 flex items-center gap-1 font-normal truncate ${
            workState === 'PRODUCTIVE' ? 'text-emerald-700' : 'text-slate-500'
          }`} title={workStateSub}>
            <span>{workStateSub}</span>
          </div>
        </div>
      </div>

      {/* ─── 2. ROW 2: TIMELINE + DONUT (GRID 2:1) ─── */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left (2 spans): Today's Activity Timeline + Hourly Focus Heatmap */}
        <div className="lg:col-span-2 bg-white border border-slate-200/90 rounded-xl p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-sm font-semibold text-slate-900">Today&apos;s Activity Timeline</h2>
              <span className="text-xs text-slate-700 bg-slate-100 border border-slate-200 px-2 py-0.5 rounded font-mono font-medium">
                {displayEvents.length > 0
                  ? `${displayEvents[0].timestamp} → ${displayEvents[displayEvents.length - 1].timestamp}`
                  : 'Waiting for stream'}
              </span>
            </div>

            {/* Segmented Timeline Bar */}
            <div className="relative">
              {displayEvents.length === 0 ? (
                <div className="h-12 w-full rounded-lg bg-slate-50 border border-dashed border-slate-200 flex flex-col items-center justify-center text-xs text-slate-400 gap-1">
                  <span>No live activity stream recorded for today yet.</span>
                  <span className="text-[11px] text-slate-400">Click &quot;Connect device&quot; above to start telemetry collection.</span>
                </div>
              ) : (
                <div className="h-9 w-full rounded-md overflow-hidden flex gap-[2px] bg-slate-100 p-0.5">
                  {displayEvents.map((evt, idx) => {
                    const dwell = evt.dwell_ms || 2000;
                    const pct = totalDwell > 0 ? (dwell / totalDwell) * 100 : 100 / displayEvents.length;
                    const bg = getSegmentColor(evt.category);
                    const dwellSec = Math.round(dwell / 1000);
                    return (
                      <div
                        key={idx}
                        onMouseEnter={() =>
                          setHoveredEvent(
                            `${evt.app_name}: ${evt.window_title} (${dwellSec}s · ${evt.timestamp})`
                          )
                        }
                        onMouseLeave={() => setHoveredEvent(null)}
                        style={{
                          width: `${Math.max(pct, 0.6)}%`,
                          backgroundColor: bg,
                        }}
                        className="h-full rounded-[2px] cursor-pointer hover:opacity-85 transition-opacity"
                        title={`${evt.app_name}: ${evt.window_title} (${dwellSec}s · ${evt.timestamp})`}
                      />
                    );
                  })}
                </div>
              )}

              {hoveredEvent && (
                <div className="absolute -top-7 left-2 bg-slate-900 text-white text-[11px] px-2 py-0.5 rounded shadow z-10 pointer-events-none truncate max-w-md">
                  {hoveredEvent}
                </div>
              )}
            </div>

            {/* Legend */}
            <div className="flex flex-wrap items-center gap-3.5 mt-3 text-xs text-slate-600">
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-[2px] bg-[#334155]" />
                <span>Deep Work</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-[2px] bg-[#22c55e]" />
                <span>Learning</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-[2px] bg-[#ef4444]" />
                <span>Distraction</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-[2px] bg-[#3b82f6]" />
                <span>Ambient</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-[2px] bg-[#f59e0b]" />
                <span>Restless</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-[2px] bg-[#06b6d4]" />
                <span>Utility</span>
              </div>
            </div>
          </div>

          <div className="mt-5 pt-4 border-t border-slate-100">
            <h3 className="text-xs font-semibold text-slate-900 mb-2">Hourly Focus Heatmap (This Week)</h3>
            {displayEvents.length === 0 ? (
              <div className="py-6 text-center text-xs text-slate-400 bg-slate-50/50 rounded-lg border border-dashed border-slate-200">
                <span>No hourly activity recorded yet this week.</span>
              </div>
            ) : (
              <div className="space-y-1">
                {heatmapComputed.map((dayRow, rIdx) => (
                  <div key={rIdx} className="grid grid-cols-24 gap-[3px]">
                    {dayRow.map((val, cIdx) => {
                      const isZero = val === 0;
                      return (
                        <div
                          key={cIdx}
                          className="h-5 rounded-[2px] transition-colors"
                          style={{
                            backgroundColor: isZero
                              ? '#e2e8f0'
                              : `rgba(37, 99, 235, ${Math.min(val * 0.9 + 0.1, 1)})`,
                          }}
                          title={`Hour ${cIdx}: ${Math.round(val * 100)}% focus`}
                        />
                      );
                    })}
                  </div>
                ))}
              </div>
            )}

            <div className="flex justify-between text-[10px] text-slate-400 mt-1.5 px-0.5">
              <span>12 AM</span>
              <span>6 AM</span>
              <span>12 PM</span>
              <span>6 PM</span>
              <span>11 PM</span>
            </div>
          </div>
        </div>

        {/* Right (1 span): Session Intent Breakdown Donut + Micro-Behavior Patterns */}
        <div className="bg-white border border-slate-200/90 rounded-xl p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-500 mb-2">
              SESSION INTENT BREAKDOWN
            </div>

            {/* SVG Donut Chart */}
            {(() => {
              if (displayEvents.length === 0) {
                return (
                  <div className="py-12 text-center text-xs text-slate-400">
                    <Compass className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                    <span>0 focus sessions recorded</span>
                  </div>
                );
              }

              let deepSec = 0;
              let learnSec = 0;
              let distSec = 0;
              let utilitySec = 0;
              let commSec = 0;

              displayEvents.forEach((e) => {
                const sec = Math.round((e.dwell_ms || 2000) / 1000);
                const cat = e.category || 'Utility';
                if (cat === 'Deep Work') deepSec += sec;
                else if (cat === 'Learning') learnSec += sec;
                else if (cat === 'Distraction' || cat === 'Entertainment') distSec += sec;
                else if (cat === 'Communication') commSec += sec;
                else utilitySec += sec;
              });

              const total = deepSec + learnSec + distSec + utilitySec + commSec || 1;
              const C = 213.63;
              const pDist = distSec / total;
              const pDeep = deepSec / total;
              const pLearn = learnSec / total;
              const pUtil = utilitySec / total;

              return (
                <div className="flex flex-col items-center justify-center my-2">
                  <div className="relative w-36 h-36">
                    <svg viewBox="0 0 100 100" className="w-full h-full -rotate-90">
                      {/* Deep Work */}
                      <circle
                        cx="50"
                        cy="50"
                        r="34"
                        fill="transparent"
                        stroke="#2563eb"
                        strokeWidth="18"
                        strokeDasharray={`${(pDeep * C).toFixed(1)} ${C.toFixed(1)}`}
                        strokeDashoffset="0"
                      />
                      {/* Learning */}
                      <circle
                        cx="50"
                        cy="50"
                        r="34"
                        fill="transparent"
                        stroke="#16a34a"
                        strokeWidth="18"
                        strokeDasharray={`${(pLearn * C).toFixed(1)} ${C.toFixed(1)}`}
                        strokeDashoffset={`${-(pDeep * C)}`}
                      />
                      {/* Distraction */}
                      <circle
                        cx="50"
                        cy="50"
                        r="34"
                        fill="transparent"
                        stroke="#dc2626"
                        strokeWidth="18"
                        strokeDasharray={`${(pDist * C).toFixed(1)} ${C.toFixed(1)}`}
                        strokeDashoffset={`${-((pDeep + pLearn) * C)}`}
                      />
                      {/* Utility */}
                      <circle
                        cx="50"
                        cy="50"
                        r="34"
                        fill="transparent"
                        stroke="#0891b2"
                        strokeWidth="18"
                        strokeDasharray={`${(pUtil * C).toFixed(1)} ${C.toFixed(1)}`}
                        strokeDashoffset={`${-((pDeep + pLearn + pDist) * C)}`}
                      />
                    </svg>
                    <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
                      <span className="text-xl font-bold text-slate-800 font-sans">
                        {Math.round((deepSec / total) * 100)}%
                      </span>
                      <span className="text-[10px] text-slate-500 font-medium">Deep Focus</span>
                    </div>
                  </div>
                </div>
              );
            })()}
          </div>

          {/* Micro-Behavior Patterns from Live Session Data */}
          <div className="mt-4 pt-4 border-t border-slate-100">
            <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-500 mb-3">
              MICRO-BEHAVIOR PATTERNS
            </div>

            {(() => {
              const rapidSwitches = activeSummary?.context_switches ?? Math.max(0, displayEvents.length - 1);
              const tabFlickers = displayEvents.filter((e) => (e.dwell_ms || 2000) <= 3000).length;
              const avgDwellSec = displayEvents.length > 0 ? (totalDwell / displayEvents.length / 1000).toFixed(1) + 's' : '0s';

              return (
                <div className="space-y-2.5 text-xs">
                  <div className="flex items-center gap-2">
                    <span className="text-slate-600 w-24 shrink-0 text-xs">Rapid Switches</span>
                    <div className="flex-1 h-2 bg-slate-100 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-blue-600 rounded-full transition-all"
                        style={{ width: `${Math.min(100, Math.max(rapidSwitches > 0 ? 8 : 0, rapidSwitches * 3))}%` }}
                      />
                    </div>
                    <span className="text-blue-600 font-semibold w-7 text-right text-xs">
                      {rapidSwitches}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-slate-600 w-24 shrink-0 text-xs">Tab Flickers</span>
                    <div className="flex-1 h-2 bg-slate-100 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-amber-500 rounded-full transition-all"
                        style={{ width: `${Math.min(100, Math.max(tabFlickers > 0 ? 8 : 0, tabFlickers * 5))}%` }}
                      />
                    </div>
                    <span className="text-amber-600 font-semibold w-7 text-right text-xs">
                      {tabFlickers}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-slate-600 w-24 shrink-0 text-xs">Avg Micro Dwell</span>
                    <div className="flex-1 h-2 bg-slate-100 rounded-full overflow-hidden">
                      <div className="h-full bg-emerald-600 rounded-full w-[45%]" />
                    </div>
                    <span className="text-slate-600 font-semibold w-7 text-right text-xs">
                      {avgDwellSec}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-slate-600 w-24 shrink-0 text-xs">Active Sessions</span>
                    <div className="flex-1 h-2 bg-slate-100 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-purple-600 rounded-full transition-all"
                        style={{ width: `${Math.min(100, Math.max(chunks.length > 0 ? 10 : 0, chunks.length * 8))}%` }}
                      />
                    </div>
                    <span className="text-purple-600 font-semibold w-7 text-right text-xs">
                      {chunks.length}
                    </span>
                  </div>
                </div>
              );
            })()}
          </div>
        </div>
      </div>

      {/* ─── 3. ROW 3: 7-DAY FOCUS VS DISTRACTION + DISTRACTION TRIGGERS (GRID 2) ─── */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Left: 7-Day Focus vs Distraction Stacked Bar Chart */}
        <div className="bg-white border border-slate-200/90 rounded-xl p-5 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">
              7-DAY FOCUS VS DISTRACTION
            </h2>
            <div className="flex items-center gap-3 text-xs text-slate-600">
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-[2px] bg-blue-600" />
                <span>Deep Work</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-[2px] bg-red-500" />
                <span>Distraction</span>
              </div>
            </div>
          </div>

          {/* Stacked Bar Chart */}
          {displayEvents.length === 0 ? (
            <div className="h-52 flex flex-col items-center justify-center text-xs text-slate-400 bg-slate-50/50 rounded-lg border border-dashed border-slate-200">
              <span>No historical telemetry recorded for this 7-day period.</span>
              <span className="text-[11px] text-slate-400 mt-1">Connect your Windows device to record daily focus metrics.</span>
            </div>
          ) : (
            <div className="h-52 relative flex flex-col justify-between pt-2">
              <div className="relative h-44 ml-4 flex items-end justify-between px-3">
                {weeklyDaysComputed.map((item, idx) => {
                  const maxVal = Math.max(60, ...weeklyDaysComputed.map((d) => d.deep + d.dist));
                  const deepH = (item.deep / maxVal) * 100;
                  const distH = (item.dist / maxVal) * 100;
                  return (
                    <div key={idx} className="flex flex-col items-center w-8">
                      <div className="w-7 flex flex-col justify-end" style={{ height: '160px' }}>
                        {item.dist > 0 && (
                          <div
                            style={{ height: `${distH}%` }}
                            className="w-full bg-red-500 rounded-t-[3px] transition-all"
                            title={`${item.day} Distraction: ${item.dist}m`}
                          />
                        )}
                        {item.deep > 0 && (
                          <div
                            style={{ height: `${deepH}%` }}
                            className={`w-full bg-blue-600 transition-all ${
                              item.dist === 0 ? 'rounded-t-[3px]' : ''
                            }`}
                            title={`${item.day} Deep Work: ${item.deep}m`}
                          />
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* X-axis Labels */}
              <div className="ml-4 flex justify-between px-3 text-[11px] text-slate-500 pt-1 border-t border-slate-200">
                {weeklyDaysComputed.map((d, i) => (
                  <span key={i} className="w-8 text-center font-medium">
                    {d.day}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Right: Distraction Triggers */}
        <div className="bg-white border border-slate-200/90 rounded-xl p-5 shadow-xs">
          <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-500 mb-4">
            DISTRACTION TRIGGERS (BY DWELL TIME)
          </div>

          <div className="space-y-4 pt-1">
            {(() => {
              const triggerMap = new Map<string, number>();
              displayEvents.forEach((e) => {
                if (e.category === 'Distraction' || e.category === 'Entertainment') {
                  const title = e.window_title || e.app_name || 'Media';
                  triggerMap.set(title, (triggerMap.get(title) || 0) + Math.round((e.dwell_ms || 2000) / 1000));
                }
              });
              const triggers = Array.from(triggerMap.entries()).sort((a, b) => b[1] - a[1]).slice(0, 5);

              if (triggers.length === 0) {
                return (
                  <div className="py-12 text-center text-xs text-slate-500">
                    <p className="font-semibold text-emerald-700">0s recorded distraction</p>
                    <p className="text-[11px] text-slate-400 mt-1">
                      {hasData
                        ? 'High focus sustained across your active desktop applications.'
                        : 'No distraction micro-events recorded yet.'}
                    </p>
                  </div>
                );
              }

              const maxDwell = triggers[0][1] || 1;
              const barColors = ['bg-red-600', 'bg-amber-600', 'bg-purple-600', 'bg-rose-500', 'bg-blue-600'];

              return triggers.map(([name, dwellSec], idx) => (
                <div key={idx} className="flex items-center gap-3 text-xs">
                  <span className="w-44 text-slate-700 truncate font-medium" title={name}>
                    {name}
                  </span>
                  <div className="flex-1 h-2 bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className={`h-full ${barColors[idx % barColors.length]} rounded-full transition-all`}
                      style={{ width: `${Math.min(100, Math.max(10, Math.round((dwellSec / maxDwell) * 100)))}%` }}
                    />
                  </div>
                  <span className="w-12 text-right text-slate-500 font-mono text-[11px]">
                    {dwellSec}s
                  </span>
                </div>
              ));
            })()}
          </div>
        </div>
      </div>
    </div>
  );
};
