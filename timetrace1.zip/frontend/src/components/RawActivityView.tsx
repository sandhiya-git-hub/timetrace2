import React, { useState, useMemo } from 'react';
import {
  Search,
  Filter,
  Download,
  ChevronLeft,
  ChevronRight,
  Shield,
  Eye,
  X,
  FileSpreadsheet,
  HelpCircle,
  Database,
  Terminal,
} from 'lucide-react';
import { TelemetryEvent } from '@shared/types/chronotrace';

interface RawActivityViewProps {
  events: TelemetryEvent[];
  onOpenDeviceModal?: () => void;
}

export const RawActivityView: React.FC<RawActivityViewProps> = ({
  events,
  onOpenDeviceModal,
}) => {
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [categoryFilter, setCategoryFilter] = useState<string>('ALL');
  const [sortOrder, setSortOrder] = useState<'newest' | 'oldest'>('newest');
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [pageSize] = useState<number>(15);
  const [selectedEvent, setSelectedEvent] = useState<TelemetryEvent | null>(null);

  // Filter out obsolete dummy seed entries when real device activities are captured
  const liveEvents = useMemo(() => {
    if (!events || events.length === 0) return [];
    const hasLive = events.some(
      (e) => e.timestamp !== '18:52:14' && !e.window_title?.includes('Switch Case - YouTube')
    );
    if (hasLive) {
      return events.filter(
        (e) => e.timestamp !== '18:52:14' && !e.window_title?.includes('Switch Case - YouTube')
      );
    }
    return events;
  }, [events]);

  // Extract categories
  const categories = useMemo(() => {
    const set = new Set<string>();
    liveEvents.forEach((e) => {
      if (e.category) set.add(e.category);
    });
    return Array.from(set);
  }, [liveEvents]);

  // Filtered dataset
  const filteredEvents = useMemo(() => {
    let list = liveEvents.filter((e) => {
      if (categoryFilter !== 'ALL' && e.category?.toLowerCase() !== categoryFilter.toLowerCase()) {
        return false;
      }
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchesApp = e.app_name?.toLowerCase().includes(q);
        const matchesTitle = e.window_title?.toLowerCase().includes(q);
        const matchesCat = e.category?.toLowerCase().includes(q);
        if (!matchesApp && !matchesTitle && !matchesCat) return false;
      }
      return true;
    });

    if (sortOrder === 'newest') {
      list = [...list].reverse();
    }
    return list;
  }, [liveEvents, categoryFilter, searchQuery, sortOrder]);

  // Pagination calculation
  const totalItems = filteredEvents.length;
  const totalPages = Math.ceil(totalItems / pageSize) || 1;
  const paginatedEvents = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredEvents.slice(start, start + pageSize);
  }, [filteredEvents, currentPage, pageSize]);

  // Export to CSV
  const handleExportCSV = () => {
    const headers = ['Date', 'Timestamp', 'Application', 'Window Title', 'Category', 'Dwell (ms)', 'Keypress Count'];
    const rows = filteredEvents.map((e) => [
      `"${e.date || (e.recorded_at ? new Date(e.recorded_at).toLocaleDateString() : '')}"`,
      `"${e.timestamp || ''}"`,
      `"${(e.app_name || '').replace(/"/g, '""')}"`,
      `"${(e.window_title || '').replace(/"/g, '""')}"`,
      `"${e.category || ''}"`,
      e.dwell_ms || 0,
      e.keyboard_events || 0,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `chronotrace_raw_activity_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const formatDwell = (ms: number) => {
    if (!ms) return '0s';
    const seconds = Math.round(ms / 1000);
    if (seconds >= 60) {
      const mins = Math.floor(seconds / 60);
      const remSec = seconds % 60;
      return `${mins}m ${remSec}s`;
    }
    return `${seconds}s`;
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">Raw Activity Log</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Audit the exact permitted events captured by the Windows background collector
          </p>
        </div>

        <button
          onClick={handleExportCSV}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 shadow-2xs transition-colors cursor-pointer self-start sm:self-auto"
        >
          <Download className="w-3.5 h-3.5 text-slate-500" />
          <span>Export CSV</span>
        </button>
      </div>

      {/* Privacy Guarantee Banner */}
      <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/80 flex items-start gap-2.5 text-xs text-slate-600">
        <Shield className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
        <p className="leading-relaxed">
          <strong className="text-slate-900 font-semibold">Privacy Compliance:</strong> All data is captured locally using pywin32 foreground hooks. Only window titles, timestamps, and typing frequency counters are stored. Keystroke characters, passwords, messages, and screenshots are never observed.
        </p>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-2xs flex flex-col sm:flex-row items-center justify-between gap-3">
        {/* Search Input */}
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setCurrentPage(1);
            }}
            placeholder="Search by window title or application..."
            className="w-full pl-9 pr-3 py-2 text-xs rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-slate-900 placeholder:text-slate-400"
          />
        </div>

        {/* Sort and Category Filters */}
        <div className="flex items-center gap-3 w-full sm:w-auto">
          {/* Sort Order Toggle */}
          <div className="flex items-center gap-1 text-xs text-slate-600">
            <button
              onClick={() => {
                setSortOrder((prev) => (prev === 'newest' ? 'oldest' : 'newest'));
                setCurrentPage(1);
              }}
              className="inline-flex items-center gap-1 px-2.5 py-2 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 font-medium cursor-pointer"
            >
              <span>Sort: {sortOrder === 'newest' ? 'Newest First' : 'Oldest First'}</span>
            </button>
          </div>

          {/* Category Filter */}
          <div className="flex items-center gap-1.5 text-xs text-slate-500 shrink-0">
            <Filter className="w-3.5 h-3.5" />
            <select
              value={categoryFilter}
              onChange={(e) => {
                setCategoryFilter(e.target.value);
                setCurrentPage(1);
              }}
              className="text-xs border border-slate-200 rounded-lg px-2.5 py-2 text-slate-700 bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer"
            >
              <option value="ALL">All Categories</option>
              {categories.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Table Container */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-2xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-medium">
              <tr>
                <th className="py-3 px-4 w-36">Time &amp; Date</th>
                <th className="py-3 px-4 w-32">Application</th>
                <th className="py-3 px-4">Window Title</th>
                <th className="py-3 px-4 w-28">Category</th>
                <th className="py-3 px-4 w-24">Dwell</th>
                <th className="py-3 px-4 w-28">Event Type</th>
                <th className="py-3 px-4 w-16 text-right">Details</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {events.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-16 text-center text-slate-500">
                    <Database className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                    <div className="font-semibold text-slate-800 text-sm">No raw telemetry events recorded yet</div>
                    <div className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
                      When the Windows telemetry agent is running, every foreground window change, application name, and dwell duration will be recorded here for auditing.
                    </div>
                    {onOpenDeviceModal && (
                      <button
                        onClick={onOpenDeviceModal}
                        className="mt-3 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-blue-600 text-white hover:bg-blue-700 cursor-pointer"
                      >
                        Connect Device
                      </button>
                    )}
                  </td>
                </tr>
              ) : paginatedEvents.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-500">
                    <HelpCircle className="w-6 h-6 text-slate-300 mx-auto mb-2" />
                    <span>No raw activity events match your filter criteria</span>
                  </td>
                </tr>
              ) : (
                paginatedEvents.map((evt, idx) => (
                  <tr key={idx} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-3 px-4 whitespace-nowrap">
                      <div className="font-mono font-semibold text-slate-900">{evt.timestamp}</div>
                      <div className="text-[10px] text-slate-500">
                        {evt.date || (evt.recorded_at ? new Date(evt.recorded_at).toLocaleDateString() : 'Today')}
                      </div>
                    </td>
                    <td className="py-3 px-4 font-semibold text-slate-900 whitespace-nowrap">
                      {evt.app_name}
                    </td>
                    <td className="py-3 px-4 text-slate-700 max-w-xs truncate" title={evt.window_title}>
                      {evt.window_title}
                    </td>
                    <td className="py-3 px-4 text-slate-600 whitespace-nowrap">
                      {evt.category}
                    </td>
                    <td className="py-3 px-4 font-mono text-slate-600 whitespace-nowrap">
                      {formatDwell(evt.dwell_ms)}
                    </td>
                    <td className="py-3 px-4 text-slate-500 whitespace-nowrap">
                      Foreground switch
                    </td>
                    <td className="py-3 px-4 text-right">
                      <button
                        onClick={() => setSelectedEvent(evt)}
                        title="View Event Details"
                        className="text-blue-600 hover:text-blue-700 font-medium p-1 rounded hover:bg-blue-50 cursor-pointer"
                      >
                        <Eye className="w-4 h-4 inline" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination controls */}
        <div className="p-3.5 border-t border-slate-200 bg-slate-50/60 flex items-center justify-between text-xs text-slate-600">
          <div>
            Showing{' '}
            <span className="font-semibold text-slate-900">
              {totalItems === 0 ? 0 : (currentPage - 1) * pageSize + 1}
            </span>{' '}
            to{' '}
            <span className="font-semibold text-slate-900">
              {Math.min(currentPage * pageSize, totalItems)}
            </span>{' '}
            of <span className="font-semibold text-slate-900">{totalItems}</span> events
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              disabled={currentPage <= 1}
              className="p-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="px-2 font-medium">
              Page {currentPage} of {totalPages}
            </span>
            <button
              onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
              disabled={currentPage >= totalPages}
              className="p-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Event Details Slide-Over Modal */}
      {selectedEvent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 p-4">
          <div className="bg-white border border-slate-200 rounded-2xl max-w-lg w-full p-6 shadow-xl relative animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Database className="w-4 h-4 text-blue-600" />
                <h3 className="font-semibold text-slate-900 text-sm">Permitted Event Inspection</h3>
              </div>
              <button
                onClick={() => setSelectedEvent(null)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-500">Timestamp:</span>
                  <span className="font-mono font-semibold text-slate-900">{selectedEvent.timestamp}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Application Executable:</span>
                  <span className="font-semibold text-slate-900">{selectedEvent.app_name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Category Tag:</span>
                  <span className="font-semibold text-blue-700">{selectedEvent.category}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Dwell Duration:</span>
                  <span className="font-mono text-slate-800">{formatDwell(selectedEvent.dwell_ms)} ({selectedEvent.dwell_ms}ms)</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Typing Activity Frequency:</span>
                  <span className="text-slate-800">{selectedEvent.keyboard_events || 0} keypresses</span>
                </div>
              </div>

              <div>
                <span className="text-slate-500 block mb-1 font-medium">Observed Window Title:</span>
                <div className="p-3 bg-slate-100/70 rounded-lg text-slate-800 font-mono text-[11px] break-all">
                  {selectedEvent.window_title}
                </div>
              </div>

              <div className="p-3 rounded-lg bg-emerald-50 border border-emerald-100 text-[11px] text-emerald-800 flex items-start gap-2">
                <Shield className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                <span>
                  No typed text, screenshots, or private content were collected. ChronoTrace samples only window metadata.
                </span>
              </div>
            </div>

            <div className="mt-5 flex justify-end">
              <button
                onClick={() => setSelectedEvent(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium rounded-lg text-xs cursor-pointer transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
