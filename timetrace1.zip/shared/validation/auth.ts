// Registration and sign-in rules shared by the React form and the Express API.
// Keeping one definition means the browser and the server can never disagree.
// Pure functions only: no DOM, no Node APIs.

export const NAME_MIN_LENGTH = 2;
export const NAME_MAX_LENGTH = 60;
export const USERNAME_MIN_LENGTH = 3;
export const USERNAME_MAX_LENGTH = 20;
export const EMAIL_MAX_LENGTH = 254;
export const PASSWORD_MIN_LENGTH = 8;
// bcrypt only uses the first 72 bytes. Rejecting longer passwords avoids silently
// accepting a password whose tail is ignored.
export const PASSWORD_MAX_BYTES = 72;

export type RegistrationField = 'name' | 'username' | 'email' | 'password' | 'confirmPassword';
export type FieldErrors = Partial<Record<RegistrationField, string>>;

export interface PasswordRule {
  id: 'length' | 'uppercase' | 'lowercase' | 'number' | 'special';
  label: string;
  test: (value: string) => boolean;
}

// Real names: letters from any script, plus spaces, apostrophes, hyphens and periods
// (O'Brien, Anne-Marie, Jr.). Must start with a letter. No digits or symbols.
const NAME_PATTERN = /^\p{L}[\p{L}\p{M} '’.-]*$/u;
const USERNAME_PATTERN = /^[A-Za-z0-9_]+$/;
const EMAIL_PATTERN =
  /^[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?(?:\.[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?)+$/;

export const PASSWORD_RULES: PasswordRule[] = [
  { id: 'length', label: `At least ${PASSWORD_MIN_LENGTH} characters`, test: (v) => v.length >= PASSWORD_MIN_LENGTH },
  { id: 'uppercase', label: 'One uppercase letter', test: (v) => /\p{Lu}/u.test(v) },
  { id: 'lowercase', label: 'One lowercase letter', test: (v) => /\p{Ll}/u.test(v) },
  { id: 'number', label: 'One number', test: (v) => /\d/.test(v) },
  { id: 'special', label: 'One special character (e.g. ! @ # $ %)', test: (v) => /[^\p{L}\p{N}\s]/u.test(v) },
];

const utf8Length = (value: string): number => new TextEncoder().encode(value).length;

// Collapses internal whitespace so "Anne   Marie " is stored as "Anne Marie".
export const normalizeName = (value: unknown): string =>
  String(value ?? '').trim().replace(/\s+/g, ' ');

export const normalizeUsername = (value: unknown): string =>
  String(value ?? '').trim().toLowerCase();

export const normalizeEmail = (value: unknown): string =>
  String(value ?? '').trim().toLowerCase();

export function validateName(value: unknown): string | null {
  const name = normalizeName(value);
  if (!name) return 'Full name is required.';
  if (name.length < NAME_MIN_LENGTH) return `Full name must be at least ${NAME_MIN_LENGTH} characters.`;
  if (name.length > NAME_MAX_LENGTH) return `Full name must be ${NAME_MAX_LENGTH} characters or fewer.`;
  if (!NAME_PATTERN.test(name)) {
    return 'Full name can only contain letters, spaces, apostrophes, hyphens and periods.';
  }
  return null;
}

export function validateUsername(value: unknown): string | null {
  const username = normalizeUsername(value);
  if (!username) return 'Username is required.';
  if (username.length < USERNAME_MIN_LENGTH || username.length > USERNAME_MAX_LENGTH) {
    return `Username must be ${USERNAME_MIN_LENGTH}–${USERNAME_MAX_LENGTH} characters.`;
  }
  if (!USERNAME_PATTERN.test(username)) {
    return 'Username can only use letters, numbers and underscores.';
  }
  return null;
}

export function validateEmail(value: unknown): string | null {
  const email = normalizeEmail(value);
  if (!email) return 'Email address is required.';
  if (email.length > EMAIL_MAX_LENGTH || !EMAIL_PATTERN.test(email)) {
    return 'Enter a valid email address, such as name@example.com.';
  }
  return null;
}

// Returns the first unmet rule's message, or null when the password is acceptable.
export function validatePassword(value: unknown): string | null {
  const password = String(value ?? '');
  if (!password) return 'Password is required.';
  const unmet = PASSWORD_RULES.find((rule) => !rule.test(password));
  if (unmet) return `Password needs: ${unmet.label.toLowerCase()}.`;
  if (utf8Length(password) > PASSWORD_MAX_BYTES) {
    return `Password must be ${PASSWORD_MAX_BYTES} bytes or fewer.`;
  }
  return null;
}

export function validateConfirmPassword(password: unknown, confirm: unknown): string | null {
  const confirmValue = String(confirm ?? '');
  if (!confirmValue) return 'Please confirm your password.';
  if (String(password ?? '') !== confirmValue) return 'Passwords do not match.';
  return null;
}

export interface RegistrationInput {
  name?: unknown;
  username?: unknown;
  email?: unknown;
  password?: unknown;
  confirmPassword?: unknown;
}

export interface RegistrationResult {
  valid: boolean;
  errors: FieldErrors;
  values: { name: string; username: string; email: string };
}

// Validates every field at once so the form can show all problems together.
// Passwords are validated exactly as typed and are never trimmed.
export function validateRegistration(input: RegistrationInput): RegistrationResult {
  const errors: FieldErrors = {};
  const name = validateName(input.name);
  const username = validateUsername(input.username);
  const email = validateEmail(input.email);
  const password = validatePassword(input.password);
  const confirm = validateConfirmPassword(input.password, input.confirmPassword);

  if (name) errors.name = name;
  if (username) errors.username = username;
  if (email) errors.email = email;
  if (password) errors.password = password;
  if (confirm) errors.confirmPassword = confirm;

  return {
    valid: Object.keys(errors).length === 0,
    errors,
    values: {
      name: normalizeName(input.name),
      username: normalizeUsername(input.username),
      email: normalizeEmail(input.email),
    },
  };
}
